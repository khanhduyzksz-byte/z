//===- FlatteningIncludes.h - Flattening Obfuscation pass------------------===//
//
//                     The LLVM Compiler Infrastructure
//
// This file is distributed under the University of Illinois Open Source
// License. See LICENSE.TXT for details.
//
//===----------------------------------------------------------------------===//
//
// This file contains includes and defines for the flattening pass
//
//===----------------------------------------------------------------------===//

#ifndef _FLATTENING_H_
#define _FLATTENING_H_

#include "common.h"

struct Flattening {
  // UP: XOR-encode the dispatcher state variable. Classic OLLVM/Hikari
  // flattening stores the raw switch-case constants, so deflattening tools
  // simply correlate the stored value with the compared case value. With
  // encoding, every store writes (case ^ key) and the dispatcher decodes
  // (load ^ key), breaking that correlation at negligible runtime cost.
  bool EncodeState = true; // fla-enc-state:true
  bool runOnFunction(Function &F);
  void flatten(Function *f);
};

#endif
