// For open-source license, please refer to
// [License](https://github.com/HikariObfuscator/Hikari/wiki/License).
//===----------------------------------------------------------------------===//

#include "Flattening.h"
#include "CryptoUtils.h"
#include "Utils.h"

bool Flattening::runOnFunction(Function &F) {
  flatten(&F);
  return true;
}

void Flattening::flatten(Function *f) {
  SmallVector<BasicBlock *, 8> origBB;
  BasicBlock *loopEntry, *loopEnd;
  LoadInst *load;
  SwitchInst *switchI;
  AllocaInst *switchVar, *switchVarAddr;
  const DataLayout &DL = f->getParent()->getDataLayout();

  // UP: per-function random state key + random IR names. The well-known
  // "switchVar"/"loopEntry" names and raw case stores are the signature
  // every deflattener looks for.
  // UP(2): the state is now affine-encoded E(c) = ((c ^ K) * M + A) with a
  // random odd multiplier M (invertible mod 2^32) and additive A. A
  // deflattener must now undo xor + mul + add in sequence to recover the
  // plain state, instead of a single xor; pattern matching on
  // "store xor(case)" or "load xor(case)" alone no longer suffices.
  const bool Enc = EncodeState;
  const uint32_t StateKey = Enc ? cryptoutils->get_uint32_t() : 0;
  const uint32_t MulM = Enc ? (cryptoutils->get_uint32_t() | 1u) : 1u;
  const uint32_t AddA = Enc ? cryptoutils->get_uint32_t() : 0u;
  // Newton-Raphson modular inverse of MulM mod 2^32 (MulM is odd, so the
  // inverse exists and this converges: 5 iterations starting from a value
  // correct mod 8 reach 2^48 bits of precision).
  uint32_t MulMInv = 1u;
  if (Enc) {
    MulMInv = MulM;
    for (int it = 0; it < 5; it++)
      MulMInv *= 2u - MulM * MulMInv;
  }
  ConstantInt *StateKeyConst =
      ConstantInt::get(Type::getInt32Ty(f->getContext()), StateKey);
  ConstantInt *MulMConst =
      ConstantInt::get(Type::getInt32Ty(f->getContext()), MulM);
  ConstantInt *AddAConst =
      ConstantInt::get(Type::getInt32Ty(f->getContext()), AddA);
  ConstantInt *MulMInvConst =
      ConstantInt::get(Type::getInt32Ty(f->getContext()), MulMInv);
  // Encode a (plain) case constant into the value stored in the state slot.
  auto EncCase = [&](ConstantInt *C) -> Constant * {
    if (!Enc)
      return C;
    const uint32_t e =
        ((((uint32_t)C->getZExtValue() ^ StateKey) * MulM) + AddA);
    return ConstantInt::get(Type::getInt32Ty(f->getContext()), e);
  };

  // SCRAMBLER
  std::unordered_map<uint32_t, uint32_t> scrambling_key;
  // END OF SCRAMBLER

  PassBuilder PB;
  FunctionAnalysisManager FAM;
  FunctionPassManager FPM;
  PB.registerFunctionAnalyses(FAM);
  FPM.addPass(LowerSwitchPass());
  FPM.run(*f, FAM);

  for (BasicBlock &BB : *f) {
    if (BB.isEHPad() || BB.isLandingPad()) {
      errs() << f->getName()
             << " Contains Exception Handing Instructions and is unsupported "
                "for flattening in the open-source version of Hikari.\n";
      return;
    }
    if (!isa<BranchInst>(BB.getTerminator()) &&
        !isa<ReturnInst>(BB.getTerminator()))
      return;
    origBB.emplace_back(&BB);
  }

  // Nothing to flatten
  if (origBB.size() <= 1)
    return;

  // Remove first BB
  origBB.erase(origBB.begin());

  // Get a pointer on the first BB
  Function::iterator tmp = f->begin();
  BasicBlock *insert = &*tmp;

  // If main begin with an if
  BranchInst *br = nullptr;
  if (isa<BranchInst>(insert->getTerminator()))
    br = cast<BranchInst>(insert->getTerminator());

  if ((br && br->isConditional()) ||
      insert->getTerminator()->getNumSuccessors() > 1) {
    BasicBlock::iterator i = insert->end();
    --i;

    if (insert->size() > 1) {
      --i;
    }

    BasicBlock *tmpBB = insert->splitBasicBlock(i, getRandomName("bb"));
    origBB.insert(origBB.begin(), tmpBB);
  }

  // Remove jump
  Instruction *oldTerm = insert->getTerminator();

  // Create switch variable and set as it
  // UP: randomized alloca name instead of the well-known "switchVar"
  switchVar = new AllocaInst(Type::getInt32Ty(f->getContext()),
                             DL.getAllocaAddrSpace(), getRandomName("v"),
                             oldTerm);
  switchVarAddr =
      new AllocaInst(Type::getInt32Ty(f->getContext())->getPointerTo(),
                     DL.getAllocaAddrSpace(), "", oldTerm);

  // UP(2) CORRECTNESS FIX: the initial dispatcher state must target the block
  // the entry actually branches to, not the first block in physical layout.
  // At -O1/-O2 LLVM lays blocks out in an order that does not necessarily
  // follow the entry's edge (rotated loops, cold blocks, inlined calls), and
  // the legacy code always stored scramble32(0) - the case of the block that
  // merely happens to sit first in the function. When those differ, the
  // first executed case is wrong and whole loops are skipped, silently
  // corrupting results (observed: an initialization loop never running and
  // downstream code reading uninitialized stack). Branches to the entry
  // successor keep working because the case numbering below assigns
  // scramble32(k) to origBB[k] and scramble32 is memoized.
  size_t initialStateIdx = 0;
  if (BranchInst *entryBr = dyn_cast<BranchInst>(oldTerm)) {
    BasicBlock *entrySucc = entryBr->getSuccessor(0);
    auto entryIt = std::find(origBB.begin(), origBB.end(), entrySucc);
    if (entryIt != origBB.end())
      initialStateIdx = (size_t)(entryIt - origBB.begin());
  }

  // Remove jump
  oldTerm->eraseFromParent();

  // UP: when encoding, the initial state is also stored XOR-ed with the key
  new StoreInst(
      EncCase(ConstantInt::get(Type::getInt32Ty(f->getContext()),
                               cryptoutils->scramble32(
                                   (uint32_t)initialStateIdx,
                                   scrambling_key))),
      switchVar, insert);
  new StoreInst(switchVar, switchVarAddr, insert);

  // Create main loop
  loopEntry = BasicBlock::Create(f->getContext(), getRandomName("bb"), f,
                                 insert);
  loopEnd =
      BasicBlock::Create(f->getContext(), getRandomName("bb"), f, insert);

  load = new LoadInst(switchVar->getAllocatedType(), switchVar,
                      getRandomName("v"), loopEntry);
  // UP: decode the state right after the load so the switch still compares
  // the plain (scrambled) case values while the stored ones are encoded.
  // UP(2): decode is now affine: D(l) = ((l - A) * MInv) ^ K, the exact
  // inverse of EncCase above.
  Value *dispatchVal = load;
  if (Enc) {
    Value *t = BinaryOperator::Create(Instruction::Sub, load, AddAConst,
                                      getRandomName("d"), loopEntry);
    t = BinaryOperator::Create(Instruction::Mul, t, MulMInvConst,
                               getRandomName("d"), loopEntry);
    dispatchVal = BinaryOperator::Create(Instruction::Xor, t, StateKeyConst,
                                         getRandomName("d"), loopEntry);
  }

  // Move first BB on top
  insert->moveBefore(loopEntry);
  BranchInst::Create(loopEntry, insert);

  // loopEnd jump to loopEntry
  BranchInst::Create(loopEntry, loopEnd);

  BasicBlock *swDefault =
      BasicBlock::Create(f->getContext(), getRandomName("bb"), f, loopEnd);
  BranchInst::Create(loopEnd, swDefault);

  // Create switch instruction itself and set condition
  switchI = SwitchInst::Create(&*f->begin(), swDefault, 0, loopEntry);
  switchI->setCondition(dispatchVal);

  // Remove branch jump from 1st BB and make a jump to the while
  f->begin()->getTerminator()->eraseFromParent();

  BranchInst::Create(loopEntry, &*f->begin());

  // Put BB in the switch
  for (BasicBlock *i : origBB) {
    ConstantInt *numCase = nullptr;

    // Move the BB inside the switch (only visual, no code logic)
    i->moveBefore(loopEnd);

    // Add case to switch
    numCase = cast<ConstantInt>(ConstantInt::get(
        switchI->getCondition()->getType(),
        cryptoutils->scramble32(switchI->getNumCases(), scrambling_key)));
    switchI->addCase(numCase, i);
  }

  // Recalculate switchVar
  for (BasicBlock *i : origBB) {
    ConstantInt *numCase = nullptr;

    // If it's a non-conditional jump
    if (i->getTerminator()->getNumSuccessors() == 1) {
      // Get successor and delete terminator
      BasicBlock *succ = i->getTerminator()->getSuccessor(0);
      i->getTerminator()->eraseFromParent();

      // Get next case
      numCase = switchI->findCaseDest(succ);

      // If next case == default case (switchDefault)
      if (!numCase) {
        numCase = cast<ConstantInt>(
            ConstantInt::get(switchI->getCondition()->getType(),
                             cryptoutils->scramble32(switchI->getNumCases() - 1,
                                                     scrambling_key)));
      }

      // Update switchVar and jump to the end of loop
      // UP: stored value is the encoded case constant
      new StoreInst(
          EncCase(numCase),
          new LoadInst(switchVarAddr->getAllocatedType(), switchVarAddr, "", i),
          i);
      BranchInst::Create(loopEnd, i);
      continue;
    }

    // If it's a conditional jump
    if (i->getTerminator()->getNumSuccessors() == 2) {
      // Get next cases
      ConstantInt *numCaseTrue =
          switchI->findCaseDest(i->getTerminator()->getSuccessor(0));
      ConstantInt *numCaseFalse =
          switchI->findCaseDest(i->getTerminator()->getSuccessor(1));

      // Check if next case == default case (switchDefault)
      if (!numCaseTrue) {
        numCaseTrue = cast<ConstantInt>(
            ConstantInt::get(switchI->getCondition()->getType(),
                             cryptoutils->scramble32(switchI->getNumCases() - 1,
                                                     scrambling_key)));
      }

      if (!numCaseFalse) {
        numCaseFalse = cast<ConstantInt>(
            ConstantInt::get(switchI->getCondition()->getType(),
                             cryptoutils->scramble32(switchI->getNumCases() - 1,
                                                     scrambling_key)));
      }

      // Create a SelectInst
      BranchInst *br = cast<BranchInst>(i->getTerminator());
      SelectInst *sel =
          SelectInst::Create(br->getCondition(), numCaseTrue, numCaseFalse, "",
                             i->getTerminator());
      // UP: encode the selected state before storing it
      // UP(2): affine encode E(sel) = ((sel ^ K) * M + A)
      Value *storeVal = sel;
      if (Enc) {
        Value *t = BinaryOperator::Create(Instruction::Xor, sel, StateKeyConst,
                                          "", i->getTerminator());
        t = BinaryOperator::Create(Instruction::Mul, t, MulMConst, "",
                                   i->getTerminator());
        storeVal = BinaryOperator::Create(Instruction::Add, t, AddAConst, "",
                                         i->getTerminator());
      }

      // Erase terminator
      i->getTerminator()->eraseFromParent();
      // Update switchVar and jump to the end of loop
      new StoreInst(
          storeVal,
          new LoadInst(switchVarAddr->getAllocatedType(), switchVarAddr, "", i),
          i);
      BranchInst::Create(loopEnd, i);
      continue;
    }
  }
  errs() << "Fixing Stack\n";
  fixStack(f);
  errs() << "Fixed Stack\n";
}

