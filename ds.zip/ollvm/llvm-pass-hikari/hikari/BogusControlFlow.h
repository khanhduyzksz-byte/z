//===- BogusControlFlow.h - BogusControlFlow Obfuscation pass-------------------------===//
//
//                     The LLVM Compiler Infrastructure
//
// This file is distributed under the University of Illinois Open Source
// License. See LICENSE.TXT for details.
//
//===--------------------------------------------------------------------------------===//
//
// This file contains includes and defines for the bogusControlFlow pass
//
//===--------------------------------------------------------------------------------===//

#ifndef _BOGUSCONTROLFLOW_H_
#define _BOGUSCONTROLFLOW_H_

#include "common.h"

struct BogusControlFlow {
  int ObfProbRate; // bcf_prob:70
  int ObfTimes; // bcf_loop:1
  int ConditionExpressionComplexity; // bcf_cond_compl:3
  bool OnlyJunkAssembly; // bcf_onlyjunkasm:false
  bool JunkAssembly; // bcf_junkasm:false
  int MaxNumberOfJunkAssembly; // bcf_junkasm_maxnum:4
  int MinNumberOfJunkAssembly; // bcf_junkasm_minnum:2
  bool CreateFunctionForOpaquePredicate; // bcf_createfunc:false
  // UP: opaque-predicate inputs are loaded volatile so GlobalOpt/InstCombine/
  // SCCP can never constant-fold the predicate chain and delete the bogus
  // blocks at any optimization level. Runtime cost is two 4-byte loads.
  bool VolatileOpaqueInputs = true; // bcf-volatile-opaque:true
  // UP(2): mix three opaque-predicate shapes instead of always emitting the
  // legacy "two globals + random binop chain + icmp" construction, so tools
  // that pattern-match the legacy BCF shape no longer match every predicate.
  bool MixedOpaque = true; // bcf-mixed-opaque:true
  // UP(2): append a semantically-dead arithmetic state machine (private GV +
  // volatile store) to each altered block, so the altered block contains
  // realistic-looking computation instead of a pure clone.
  bool JunkAlu = true; // bcf-junk-alu:true
  // UP(2): probabilistically wrap a block with a second opaque layer
  // (same CFG shape the bcf_loop>1 path already produces).
  bool ExtraLayer = true; // bcf-extra-layer:true
  SmallVector<const ICmpInst *, 8> needtoedit;

  bool runOnFunction(Function &F);
  void bogus(Function &F);
  bool containsCoroBeginInst(BasicBlock *b);
  bool containsMustTailCall(BasicBlock *b);
  bool containsSwiftError(BasicBlock *b);
  void addBogusFlow(BasicBlock *basicBlock, Function &F);
  BasicBlock *createAlteredBasicBlock(BasicBlock *basicBlock, const Twine &Name = "gen", Function *F = nullptr);
  bool doF(Function &F);
  // UP(2): build a single-global always-true opaque predicate and rewire the
  // given conditional branch to use it. shape 0: (y*KEven) % 2 == 0;
  // shape 1: (y ^ 1) == (y + 1 - 2*(y & 1)). Both are tautologies over
  // Z/2^n for every 32-bit y, including signed and wrapped values.
  bool buildCheapOpaquePredicate(Instruction *branch, int shape);
};

#endif
