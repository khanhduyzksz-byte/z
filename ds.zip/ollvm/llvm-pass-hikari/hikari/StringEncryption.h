#ifndef _STRING_ENCRYPTION_H_
#define _STRING_ENCRYPTION_H_

#include "common.h"
#include <array>

struct StringEncryption {
        uint32_t ElementEncryptProb; // strcry_prob:100
        bool appleptrauth;
        bool opaquepointers;
        // UP: materialize decryption keys into a private constant global and
        // read them with volatile loads, so the key bytes no longer appear as
        // XOR immediates in the code stream. This defeats byte-pattern
        // scanners that look for "xor [mem], imm" decryption loops.
        bool KeyViaGV = true; // strcry-key-gv:true
        // UP(2): rolling-key decryption. The per-element key is no longer
        // static data: at runtime the key register starts from a volatile-
        // loaded seed K0 and is re-mixed after every element
        // (k = k * P + Q, P odd). The static key array still exists in the
        // data section as a decoy, but the code never reads it, so known-
        // plaintext/differential attacks against the emitted loop can no
        // longer recover a reusable key table.
        bool RollingKey = true; // strcry-rolling-key:true
        std::unordered_map<Function *, GlobalVariable * /*Decryption Status*/> encstatus;
        std::unordered_map<GlobalVariable *, std::pair<Constant *, GlobalVariable *>> mgv2keys;
        std::unordered_map<Constant *, SmallVector<unsigned int, 16>> unencryptedindex;
        std::unordered_map<Constant *, GlobalVariable *> keygvmap;
        // UP(2): per-string rolling-key parameters (K0, P, Q) keyed by the
        // key Constant so the decryption loop can rebuild the chain.
        std::unordered_map<Constant *, std::array<uint64_t, 3>> rollingparams;
        // UP(2): seed globals backing the volatile K0 loads.
        std::unordered_map<Constant *, GlobalVariable *> seedgvmap;
        SmallVector<GlobalVariable *, 32> genedgv;

        bool initialize(Module &M);
        bool handleableGV(GlobalVariable *GV);
        bool runOnFunction(Function &F);
        void processConstantAggregate(GlobalVariable *strGV, ConstantAggregate *CA,
                std::set<GlobalVariable *> *rawStrings,
                SmallVector<GlobalVariable *, 32> *unhandleablegvs,
                SmallVector<GlobalVariable *, 32> *Globals,
                std::set<User *> *Users, bool *breakFor);
        void HandleUser(User *U, SmallVector<GlobalVariable *, 32> &Globals,
                std::set<User *> &Users,
                std::unordered_set<User *> &VisitedUsers);
        void HandleFunction(Function *Func);
        GlobalVariable *ObjectiveCString(GlobalVariable *GV, std::string name,
                GlobalVariable *newString,
                ConstantStruct *CS);
        void HandleDecryptionBlock(BasicBlock *B, BasicBlock *C,
        std::unordered_map<GlobalVariable *,
        std::pair<Constant *, GlobalVariable *>> &GV2Keys);
};

#endif
