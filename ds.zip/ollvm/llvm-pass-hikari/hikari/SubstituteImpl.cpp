//===----------------------------------------------------------------------===//

#include "SubstituteImpl.h"
#include "CryptoUtils.h"

// UP: sizes extended with Mixed Boolean-Arithmetic (MBA) variants.
// Classic OLLVM substitutions are recognized and collapsed by modern
// algebra-simplifiers (IDA/Simplify, BinaryNinja Hikari removers, Syntia,
// SSPAM). MBA identities mixing arithmetic (+,-,*) with bitwise (&,|,^,~)
// are algebraically harder for SMT-free simplifiers and are the current
// standard in commercial obfuscators.
// UP(2): added depth-2 composites (MBA + De Morgan nesting). These compose
// two independent identities into one expression DAG, so single-rule
// rewriters must fire multiple times in the right order to collapse them.
#define NUMBER_ADD_SUBST 9
#define NUMBER_SUB_SUBST 9
#define NUMBER_AND_SUBST 9
#define NUMBER_OR_SUBST 8
#define NUMBER_XOR_SUBST 11
#define NUMBER_MUL_SUBST 2

static void addNeg(BinaryOperator *bo);
static void addDoubleNeg(BinaryOperator *bo);
static void addRand(BinaryOperator *bo);
static void addRand2(BinaryOperator *bo);
static void addSubstitution(BinaryOperator *bo);
static void addSubstitution2(BinaryOperator *bo);
static void addSubstitution3(BinaryOperator *bo);
static void addSubstitutionMBA(BinaryOperator *bo);
static void addSubstitutionMBA2(BinaryOperator *bo);

static void subNeg(BinaryOperator *bo);
static void subRand(BinaryOperator *bo);
static void subRand2(BinaryOperator *bo);
static void subSubstitution(BinaryOperator *bo);
static void subSubstitution2(BinaryOperator *bo);
static void subSubstitution3(BinaryOperator *bo);
static void subSubstitutionMBA(BinaryOperator *bo);
static void subSubstitutionMBA2(BinaryOperator *bo);
static void subSubstitutionMBA3(BinaryOperator *bo);

static void andSubstitution(BinaryOperator *bo);
static void andSubstitution2(BinaryOperator *bo);
static void andSubstitution3(BinaryOperator *bo);
static void andSubstitutionRand(BinaryOperator *bo);
static void andNor(BinaryOperator *bo);
static void andNand(BinaryOperator *bo);
static void andSubstitutionMBA(BinaryOperator *bo);
static void andSubstitutionMBA2(BinaryOperator *bo);
static void andSubstitutionMBA3(BinaryOperator *bo);

static void orSubstitution(BinaryOperator *bo);
static void orSubstitution2(BinaryOperator *bo);
static void orSubstitution3(BinaryOperator *bo);
static void orSubstitutionRand(BinaryOperator *bo);
static void orNor(BinaryOperator *bo);
static void orNand(BinaryOperator *bo);
static void orSubstitutionMBA(BinaryOperator *bo);
static void orSubstitutionMBA2(BinaryOperator *bo);

static void xorSubstitution(BinaryOperator *bo);
static void xorSubstitution2(BinaryOperator *bo);
static void xorSubstitution3(BinaryOperator *bo);
static void xorSubstitutionRand(BinaryOperator *bo);
static void xorNor(BinaryOperator *bo);
static void xorNand(BinaryOperator *bo);
static void xorSubstitutionMBA(BinaryOperator *bo);
static void xorSubstitutionMBA2(BinaryOperator *bo);
static void xorSubstitutionMBA3(BinaryOperator *bo);
static void xorSubstitutionMBA4(BinaryOperator *bo);
static void xorSubstitutionMBA5(BinaryOperator *bo);

static void mulSubstitution(BinaryOperator *bo);
static void mulSubstitution2(BinaryOperator *bo);

static void (*funcAdd[NUMBER_ADD_SUBST])(BinaryOperator *bo) = {
    &addNeg,          &addDoubleNeg,     &addRand,         &addRand2,
    &addSubstitution, &addSubstitution2, &addSubstitution3,
    &addSubstitutionMBA, &addSubstitutionMBA2};
static void (*funcSub[NUMBER_SUB_SUBST])(BinaryOperator *bo) = {
    &subNeg,          &subRand,          &subRand2,
    &subSubstitution, &subSubstitution2, &subSubstitution3,
    &subSubstitutionMBA, &subSubstitutionMBA2, &subSubstitutionMBA3};
static void (*funcAnd[NUMBER_AND_SUBST])(BinaryOperator *bo) = {
    &andSubstitution,     &andSubstitution2, &andSubstitution3,
    &andSubstitutionRand, &andNor,           &andNand,
    &andSubstitutionMBA,  &andSubstitutionMBA2, &andSubstitutionMBA3};
static void (*funcOr[NUMBER_OR_SUBST])(BinaryOperator *bo) = {
    &orSubstitution,     &orSubstitution2, &orSubstitution3,
    &orSubstitutionRand, &orNor,           &orNand,
    &orSubstitutionMBA,  &orSubstitutionMBA2};
static void (*funcXor[NUMBER_XOR_SUBST])(BinaryOperator *bo) = {
    &xorSubstitution,     &xorSubstitution2, xorSubstitution3,
    &xorSubstitutionRand, &xorNor,           &xorNand,
    &xorSubstitutionMBA,  &xorSubstitutionMBA2, &xorSubstitutionMBA3,
    &xorSubstitutionMBA4, &xorSubstitutionMBA5};
static void (*funcMul[NUMBER_MUL_SUBST])(BinaryOperator *bo) = {
    &mulSubstitution, &mulSubstitution2};

void SubstituteImpl::substituteAdd(BinaryOperator *bo) {
  (*funcAdd[cryptoutils->get_range(NUMBER_ADD_SUBST)])(bo);
}
void SubstituteImpl::substituteSub(BinaryOperator *bo) {
  (*funcSub[cryptoutils->get_range(NUMBER_SUB_SUBST)])(bo);
}
void SubstituteImpl::substituteAnd(BinaryOperator *bo) {
  (*funcAnd[cryptoutils->get_range(NUMBER_AND_SUBST)])(bo);
}
void SubstituteImpl::substituteOr(BinaryOperator *bo) {
  (*funcOr[cryptoutils->get_range(NUMBER_OR_SUBST)])(bo);
}
void SubstituteImpl::substituteXor(BinaryOperator *bo) {
  (*funcXor[cryptoutils->get_range(NUMBER_XOR_SUBST)])(bo);
}
void SubstituteImpl::substituteMul(BinaryOperator *bo) {
  (*funcMul[cryptoutils->get_range(NUMBER_MUL_SUBST)])(bo);
}

// Implementation of ~(a | b) and ~a & ~b
static BinaryOperator *buildNor(Value *a, Value *b, Instruction *insertBefore) {
  switch (cryptoutils->get_range(2)) {
  case 0: {
    // ~(a | b)
    BinaryOperator *op =
        BinaryOperator::Create(Instruction::Or, a, b, "", insertBefore);
    op = BinaryOperator::CreateNot(op, "", insertBefore);
    return op;
  }
  case 1: {
    // ~a & ~b
    BinaryOperator *nota = BinaryOperator::CreateNot(a, "", insertBefore);
    BinaryOperator *notb = BinaryOperator::CreateNot(b, "", insertBefore);
    BinaryOperator *op =
        BinaryOperator::Create(Instruction::And, nota, notb, "", insertBefore);
    return op;
  }
  default:
    llvm_unreachable("wtf?");
  }
}

// Implementation of ~(a & b) and ~a | ~b
static BinaryOperator *buildNand(Value *a, Value *b,
                                 Instruction *insertBefore) {
  switch (cryptoutils->get_range(2)) {
  case 0: {
    // ~(a & b)
    BinaryOperator *op =
        BinaryOperator::Create(Instruction::And, a, b, "", insertBefore);
    op = BinaryOperator::CreateNot(op, "", insertBefore);
    return op;
  }
  case 1: {
    // ~a | ~b
    BinaryOperator *nota = BinaryOperator::CreateNot(a, "", insertBefore);
    BinaryOperator *notb = BinaryOperator::CreateNot(b, "", insertBefore);
    BinaryOperator *op =
        BinaryOperator::Create(Instruction::Or, nota, notb, "", insertBefore);
    return op;
  }
  default:
    llvm_unreachable("wtf?");
  }
}

// Implementation of a = b - (-c)
static void addNeg(BinaryOperator *bo) {
  BinaryOperator *op = BinaryOperator::CreateNeg(bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Sub, bo->getOperand(0), op, "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = -(-b + (-c))
static void addDoubleNeg(BinaryOperator *bo) {
  BinaryOperator *op = BinaryOperator::CreateNeg(bo->getOperand(0), "", bo);
  BinaryOperator *op2 = BinaryOperator::CreateNeg(bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Add, op, op2, "", bo);
  op = BinaryOperator::CreateNeg(op, "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of  r = rand (); a = b + r; a = a + c; a = a - r
static void addRand(BinaryOperator *bo) {
  ConstantInt *co = (ConstantInt *)ConstantInt::get(
      bo->getType(), cryptoutils->get_uint64_t());
  BinaryOperator *op =
      BinaryOperator::Create(Instruction::Add, bo->getOperand(0), co, "", bo);
  op = BinaryOperator::Create(Instruction::Add, op, bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Sub, op, co, "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of r = rand (); a = b - r; a = a + b; a = a + r
static void addRand2(BinaryOperator *bo) {
  ConstantInt *co = (ConstantInt *)ConstantInt::get(
      bo->getType(), cryptoutils->get_uint64_t());
  BinaryOperator *op =
      BinaryOperator::Create(Instruction::Sub, bo->getOperand(0), co, "", bo);
  op = BinaryOperator::Create(Instruction::Add, op, bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Add, op, co, "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = b + c => a = b - ~c - 1
static void addSubstitution(BinaryOperator *bo) {
  ConstantInt *co = (ConstantInt *)ConstantInt::get(bo->getType(), 1);
  BinaryOperator *op = BinaryOperator::CreateNot(bo->getOperand(1), "", bo);
  BinaryOperator *op1 = BinaryOperator::CreateNeg(co, "", bo);
  op = BinaryOperator::Create(Instruction::Sub, op, op1, "", bo);
  op = BinaryOperator::Create(Instruction::Sub, bo->getOperand(0), op, "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = b + c => a = (b | c) + (b & c)
static void addSubstitution2(BinaryOperator *bo) {
  BinaryOperator *op = BinaryOperator::Create(
      Instruction::And, bo->getOperand(0), bo->getOperand(1), "", bo);
  BinaryOperator *op1 = BinaryOperator::Create(
      Instruction::Or, bo->getOperand(0), bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Add, op, op1, "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = b + c => a = (b ^ c) + (b & c) * 2
static void addSubstitution3(BinaryOperator *bo) {
  ConstantInt *co = (ConstantInt *)ConstantInt::get(bo->getType(), 2);
  BinaryOperator *op = BinaryOperator::Create(
      Instruction::And, bo->getOperand(0), bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Mul, op, co, "", bo);
  BinaryOperator *op1 = BinaryOperator::Create(
      Instruction::Xor, bo->getOperand(0), bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Add, op1, op, "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = b + (-c)
static void subNeg(BinaryOperator *bo) {
  BinaryOperator *op = BinaryOperator::CreateNeg(bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Add, bo->getOperand(0), op, "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of  r = rand (); a = b + r; a = a - c; a = a - r
static void subRand(BinaryOperator *bo) {
  ConstantInt *co = (ConstantInt *)ConstantInt::get(
      bo->getType(), cryptoutils->get_uint64_t());
  BinaryOperator *op =
      BinaryOperator::Create(Instruction::Add, bo->getOperand(0), co, "", bo);
  op = BinaryOperator::Create(Instruction::Sub, op, bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Sub, op, co, "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of  r = rand (); a = b - r; a = a - c; a = a + r
static void subRand2(BinaryOperator *bo) {
  ConstantInt *co = (ConstantInt *)ConstantInt::get(
      bo->getType(), cryptoutils->get_uint64_t());
  BinaryOperator *op =
      BinaryOperator::Create(Instruction::Sub, bo->getOperand(0), co, "", bo);
  op = BinaryOperator::Create(Instruction::Sub, op, bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Add, op, co, "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = b - c => a = (b & ~c) - (~b & c)
static void subSubstitution(BinaryOperator *bo) {
  BinaryOperator *op1 = BinaryOperator::CreateNot(bo->getOperand(0), "", bo);
  BinaryOperator *op =
      BinaryOperator::Create(Instruction::And, op1, bo->getOperand(1), "", bo);
  op1 = BinaryOperator::CreateNot(bo->getOperand(1), "", bo);
  BinaryOperator *op2 =
      BinaryOperator::Create(Instruction::And, bo->getOperand(0), op1, "", bo);
  op = BinaryOperator::Create(Instruction::Sub, op2, op, "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = b - c => a = (2 * (b & ~c)) - (b ^ c)
static void subSubstitution2(BinaryOperator *bo) {
  ConstantInt *co = (ConstantInt *)ConstantInt::get(bo->getType(), 2);
  BinaryOperator *op1 = BinaryOperator::Create(
      Instruction::Xor, bo->getOperand(0), bo->getOperand(1), "", bo);
  BinaryOperator *op = BinaryOperator::CreateNot(bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::And, bo->getOperand(0), op, "", bo);
  op = BinaryOperator::Create(Instruction::Mul, co, op, "", bo);
  op = BinaryOperator::Create(Instruction::Sub, op, op1, "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = b - c => a = b + ~c + 1
static void subSubstitution3(BinaryOperator *bo) {
  ConstantInt *co = (ConstantInt *)ConstantInt::get(bo->getType(), 1);
  BinaryOperator *op1 = BinaryOperator::CreateNot(bo->getOperand(1), "", bo);
  BinaryOperator *op =
      BinaryOperator::Create(Instruction::Add, bo->getOperand(0), op1, "", bo);
  op = BinaryOperator::Create(Instruction::Add, op, co, "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = b & c => a = (b ^ ~c) & b
static void andSubstitution(BinaryOperator *bo) {
  BinaryOperator *op = BinaryOperator::CreateNot(bo->getOperand(1), "", bo);
  BinaryOperator *op1 =
      BinaryOperator::Create(Instruction::Xor, bo->getOperand(0), op, "", bo);
  op = BinaryOperator::Create(Instruction::And, op1, bo->getOperand(0), "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = b & c => a = (b | c) & ~(b ^ c)
static void andSubstitution2(BinaryOperator *bo) {
  BinaryOperator *op1 = BinaryOperator::Create(
      Instruction::Xor, bo->getOperand(0), bo->getOperand(1), "", bo);
  op1 = BinaryOperator::CreateNot(op1, "", bo);
  BinaryOperator *op = BinaryOperator::Create(
      Instruction::Or, bo->getOperand(0), bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::And, op, op1, "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = b & c => a = (~b | c) + (b + 1)
static void andSubstitution3(BinaryOperator *bo) {
  ConstantInt *co = (ConstantInt *)ConstantInt::get(bo->getType(), 1);
  BinaryOperator *op1 =
      BinaryOperator::Create(Instruction::Add, bo->getOperand(0), co, "", bo);
  BinaryOperator *op = BinaryOperator::CreateNot(bo->getOperand(0), "", bo);
  op = BinaryOperator::Create(Instruction::Or, op, bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Add, op, op1, "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = a & b <=> ~(~a | ~b) & (r | ~r)
static void andSubstitutionRand(BinaryOperator *bo) {
  ConstantInt *co = (ConstantInt *)ConstantInt::get(
      bo->getType(), cryptoutils->get_uint64_t());
  BinaryOperator *op = BinaryOperator::CreateNot(bo->getOperand(0), "", bo);
  BinaryOperator *op1 = BinaryOperator::CreateNot(bo->getOperand(1), "", bo);
  BinaryOperator *opr = BinaryOperator::CreateNot(co, "", bo);
  BinaryOperator *opa =
      BinaryOperator::Create(Instruction::Or, op, op1, "", bo);
  opr = BinaryOperator::Create(Instruction::Or, co, opr, "", bo);
  op = BinaryOperator::CreateNot(opa, "", bo);
  op = BinaryOperator::Create(Instruction::And, op, opr, "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = a & b => Nor(Nor(a, a), Nor(b, b))
static void andNor(BinaryOperator *bo) {
  BinaryOperator *noraa = buildNor(bo->getOperand(0), bo->getOperand(0), bo);
  BinaryOperator *norbb = buildNor(bo->getOperand(1), bo->getOperand(1), bo);
  bo->replaceAllUsesWith(buildNor(noraa, norbb, bo));
}

// Implementation of a = a & b => Nand(Nand(a, b), Nand(a, b))
static void andNand(BinaryOperator *bo) {
  BinaryOperator *nandab = buildNand(bo->getOperand(0), bo->getOperand(1), bo);
  BinaryOperator *nandab2 = buildNand(bo->getOperand(0), bo->getOperand(1), bo);
  bo->replaceAllUsesWith(buildNand(nandab, nandab2, bo));
}

// Implementation of a = a | b => a = (b & c) | (b ^ c)
static void orSubstitution(BinaryOperator *bo) {
  BinaryOperator *op = BinaryOperator::Create(
      Instruction::And, bo->getOperand(0), bo->getOperand(1), "", bo);
  BinaryOperator *op1 = BinaryOperator::Create(
      Instruction::Xor, bo->getOperand(0), bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Or, op, op1, "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = a | b => a = (b + (b ^ c)) - (b & ~c)
static void orSubstitution2(BinaryOperator *bo) {
  BinaryOperator *op1 = BinaryOperator::CreateNot(bo->getOperand(1), "", bo);
  op1 =
      BinaryOperator::Create(Instruction::And, bo->getOperand(0), op1, "", bo);
  BinaryOperator *op = BinaryOperator::Create(
      Instruction::Xor, bo->getOperand(0), bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Add, bo->getOperand(0), op, "", bo);
  op = BinaryOperator::Create(Instruction::Sub, op, op1, "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = a | b => a = (b + c + 1) + ~(c & b)
static void orSubstitution3(BinaryOperator *bo) {
  ConstantInt *co = (ConstantInt *)ConstantInt::get(bo->getType(), 1);
  BinaryOperator *op1 = BinaryOperator::Create(
      Instruction::And, bo->getOperand(1), bo->getOperand(0), "", bo);
  op1 = BinaryOperator::CreateNot(op1, "", bo);
  BinaryOperator *op = BinaryOperator::Create(
      Instruction::Add, bo->getOperand(0), bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Add, op, co, "", bo);
  op = BinaryOperator::Create(Instruction::Add, op, op1, "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = b | c => a = (((~a & r) | (a & ~r)) ^ ((~b & r) | (b &
// ~r))) | (~(~a | ~b) & (r | ~r))
static void orSubstitutionRand(BinaryOperator *bo) {
  ConstantInt *co = (ConstantInt *)ConstantInt::get(
      bo->getType(), cryptoutils->get_uint64_t());
  BinaryOperator *op = BinaryOperator::CreateNot(bo->getOperand(0), "", bo);
  BinaryOperator *op1 = BinaryOperator::CreateNot(bo->getOperand(1), "", bo);
  BinaryOperator *op2 = BinaryOperator::CreateNot(co, "", bo);
  BinaryOperator *op3 =
      BinaryOperator::Create(Instruction::And, op, co, "", bo);
  BinaryOperator *op4 =
      BinaryOperator::Create(Instruction::And, bo->getOperand(0), op2, "", bo);
  BinaryOperator *op5 =
      BinaryOperator::Create(Instruction::And, op1, co, "", bo);
  BinaryOperator *op6 =
      BinaryOperator::Create(Instruction::And, bo->getOperand(1), op2, "", bo);
  op3 = BinaryOperator::Create(Instruction::Or, op3, op4, "", bo);
  op4 = BinaryOperator::Create(Instruction::Or, op5, op6, "", bo);
  op5 = BinaryOperator::Create(Instruction::Xor, op3, op4, "", bo);
  op3 = BinaryOperator::Create(Instruction::Or, op, op1, "", bo);
  op3 = BinaryOperator::CreateNot(op3, "", bo);
  op4 = BinaryOperator::Create(Instruction::Or, co, op2, "", bo);
  op4 = BinaryOperator::Create(Instruction::And, op3, op4, "", bo);
  op = BinaryOperator::Create(Instruction::Or, op5, op4, "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = a | b => a = Nor(Nor(a, b), Nor(a, b))
static void orNor(BinaryOperator *bo) {
  BinaryOperator *norab = buildNor(bo->getOperand(0), bo->getOperand(1), bo);
  BinaryOperator *norab2 = buildNor(bo->getOperand(0), bo->getOperand(1), bo);
  BinaryOperator *op = buildNor(norab, norab2, bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = a | b => a = Nand(Nand(a, a), Nand(b, b))
static void orNand(BinaryOperator *bo) {
  BinaryOperator *nandaa = buildNand(bo->getOperand(0), bo->getOperand(0), bo);
  BinaryOperator *nandbb = buildNand(bo->getOperand(1), bo->getOperand(1), bo);
  BinaryOperator *op = buildNand(nandaa, nandbb, bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = a ^ b => a = (~a & b) | (a & ~b)
static void xorSubstitution(BinaryOperator *bo) {
  BinaryOperator *op = BinaryOperator::CreateNot(bo->getOperand(0), "", bo);
  op = BinaryOperator::Create(Instruction::And, bo->getOperand(1), op, "", bo);
  BinaryOperator *op1 = BinaryOperator::CreateNot(bo->getOperand(1), "", bo);
  op1 =
      BinaryOperator::Create(Instruction::And, bo->getOperand(0), op1, "", bo);
  op = BinaryOperator::Create(Instruction::Or, op, op1, "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = a ^ b => a = (b + c) - 2 * (b & c)
static void xorSubstitution2(BinaryOperator *bo) {
  ConstantInt *co = (ConstantInt *)ConstantInt::get(bo->getType(), 2);
  BinaryOperator *op1 = BinaryOperator::Create(
      Instruction::And, bo->getOperand(0), bo->getOperand(1), "", bo);
  op1 = BinaryOperator::Create(Instruction::Mul, co, op1, "", bo);
  BinaryOperator *op = BinaryOperator::Create(
      Instruction::Add, bo->getOperand(0), bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Sub, op, op1, "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = a ^ b => a = b - (2 * (c & ~(b ^ c)) - c)
static void xorSubstitution3(BinaryOperator *bo) {
  ConstantInt *co = (ConstantInt *)ConstantInt::get(bo->getType(), 2);
  BinaryOperator *op1 = BinaryOperator::Create(
      Instruction::Xor, bo->getOperand(0), bo->getOperand(1), "", bo);
  op1 = BinaryOperator::CreateNot(op1, "", bo);
  op1 =
      BinaryOperator::Create(Instruction::And, bo->getOperand(1), op1, "", bo);
  op1 = BinaryOperator::Create(Instruction::Mul, co, op1, "", bo);
  op1 =
      BinaryOperator::Create(Instruction::Sub, op1, bo->getOperand(1), "", bo);
  BinaryOperator *op =
      BinaryOperator::Create(Instruction::Sub, bo->getOperand(0), op1, "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = a ^ b <=> (a ^ r) ^ (b ^ r) <=> (~a & r | a & ~r) ^ (~b
// & r | b & ~r) note : r is a random number
static void xorSubstitutionRand(BinaryOperator *bo) {
  ConstantInt *co = (ConstantInt *)ConstantInt::get(
      bo->getType(), cryptoutils->get_uint64_t());
  BinaryOperator *op = BinaryOperator::CreateNot(bo->getOperand(0), "", bo);
  op = BinaryOperator::Create(Instruction::And, co, op, "", bo);
  BinaryOperator *opr = BinaryOperator::CreateNot(co, "", bo);
  BinaryOperator *op1 =
      BinaryOperator::Create(Instruction::And, bo->getOperand(0), opr, "", bo);
  BinaryOperator *op2 = BinaryOperator::CreateNot(bo->getOperand(1), "", bo);
  op2 = BinaryOperator::Create(Instruction::And, op2, co, "", bo);
  BinaryOperator *op3 =
      BinaryOperator::Create(Instruction::And, bo->getOperand(1), opr, "", bo);
  op = BinaryOperator::Create(Instruction::Or, op, op1, "", bo);
  op1 = BinaryOperator::Create(Instruction::Or, op2, op3, "", bo);
  op = BinaryOperator::Create(Instruction::Xor, op, op1, "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = a ^ b => a = Nor(Nor(Nor(a, a), Nor(b, b)), Nor(a, b))
static void xorNor(BinaryOperator *bo) {
  BinaryOperator *noraa = buildNor(bo->getOperand(0), bo->getOperand(0), bo);
  BinaryOperator *norbb = buildNor(bo->getOperand(1), bo->getOperand(1), bo);
  BinaryOperator *nornoraanorbb = buildNor(noraa, norbb, bo);
  BinaryOperator *norab = buildNor(bo->getOperand(0), bo->getOperand(1), bo);
  BinaryOperator *op = buildNor(nornoraanorbb, norab, bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = a ^ b => a = Nand(Nand(Nand(a, a), b), Nand(a, Nand(b,
// b)))
static void xorNand(BinaryOperator *bo) {
  BinaryOperator *nandaa = buildNand(bo->getOperand(0), bo->getOperand(0), bo);
  BinaryOperator *nandnandaab = buildNand(nandaa, bo->getOperand(1), bo);
  BinaryOperator *nandbb = buildNand(bo->getOperand(1), bo->getOperand(1), bo);
  BinaryOperator *nandanandbb = buildNand(bo->getOperand(0), nandbb, bo);
  BinaryOperator *op = buildNand(nandnandaab, nandanandbb, bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = b * c => a = (((b | c) * (b & c)) + ((b & ~c) * (c &
// ~b)))
static void mulSubstitution(BinaryOperator *bo) {
  BinaryOperator *op1 = BinaryOperator::CreateNot(bo->getOperand(0), "", bo);
  op1 =
      BinaryOperator::Create(Instruction::And, bo->getOperand(1), op1, "", bo);
  BinaryOperator *op2 = BinaryOperator::CreateNot(bo->getOperand(1), "", bo);
  op2 =
      BinaryOperator::Create(Instruction::And, bo->getOperand(0), op2, "", bo);
  BinaryOperator *op =
      BinaryOperator::Create(Instruction::Mul, op2, op1, "", bo);
  op1 = BinaryOperator::Create(Instruction::And, bo->getOperand(0),
                               bo->getOperand(1), "", bo);
  op2 = BinaryOperator::Create(Instruction::Or, bo->getOperand(0),
                               bo->getOperand(1), "", bo);
  BinaryOperator *op3 =
      BinaryOperator::Create(Instruction::Mul, op2, op1, "", bo);
  op = BinaryOperator::Create(Instruction::Add, op3, op, "", bo);
  bo->replaceAllUsesWith(op);
}

// Implementation of a = b * c => a = (((b | c) * (b & c)) + ((~(b | ~c)) * (b &
// ~c)))
static void mulSubstitution2(BinaryOperator *bo) {
  BinaryOperator *op1 = BinaryOperator::CreateNot(bo->getOperand(1), "", bo);
  BinaryOperator *op2 =
      BinaryOperator::Create(Instruction::And, bo->getOperand(0), op1, "", bo);
  BinaryOperator *op3 =
      BinaryOperator::Create(Instruction::Or, bo->getOperand(0), op1, "", bo);
  op3 = BinaryOperator::CreateNot(op3, "", bo);
  op3 = BinaryOperator::Create(Instruction::Mul, op3, op2, "", bo);
  BinaryOperator *op4 = BinaryOperator::Create(
      Instruction::And, bo->getOperand(0), bo->getOperand(1), "", bo);
  BinaryOperator *op5 = BinaryOperator::Create(
      Instruction::Or, bo->getOperand(0), bo->getOperand(1), "", bo);
  op5 = BinaryOperator::Create(Instruction::Mul, op5, op4, "", bo);
  BinaryOperator *op =
      BinaryOperator::Create(Instruction::Add, op5, op3, "", bo);
  bo->replaceAllUsesWith(op);
}

//===----------------------------------------------------------------------===//
// UP: Mixed Boolean-Arithmetic (MBA) substitutions.
// All identities below hold exactly over Z/2^n (two's complement) for every
// integer width and for element-wise vector ops, therefore they are
// drop-in safe for any integer BinaryOperator the existing pass already
// handles. They intentionally interleave the boolean and the arithmetic
// domain, which breaks pure pattern/simplification-based deobfuscation.
//===----------------------------------------------------------------------===//

// MBA: a = b + c => a = 2 * (b | c) - (b ^ c)
static void addSubstitutionMBA(BinaryOperator *bo) {
  ConstantInt *co = (ConstantInt *)ConstantInt::get(bo->getType(), 2);
  BinaryOperator *op = BinaryOperator::Create(
      Instruction::Or, bo->getOperand(0), bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Mul, co, op, "", bo);
  BinaryOperator *op1 = BinaryOperator::Create(
      Instruction::Xor, bo->getOperand(0), bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Sub, op, op1, "", bo);
  bo->replaceAllUsesWith(op);
}

// MBA: a = b - c => a = (b ^ c) - 2 * (~b & c)
static void subSubstitutionMBA(BinaryOperator *bo) {
  ConstantInt *co = (ConstantInt *)ConstantInt::get(bo->getType(), 2);
  BinaryOperator *notb = BinaryOperator::CreateNot(bo->getOperand(0), "", bo);
  BinaryOperator *op = BinaryOperator::Create(Instruction::And, notb,
                                              bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Mul, co, op, "", bo);
  BinaryOperator *op1 = BinaryOperator::Create(
      Instruction::Xor, bo->getOperand(0), bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Sub, op1, op, "", bo);
  bo->replaceAllUsesWith(op);
}

// MBA: a = b - c => a = ~(~b + c)
// (~ is the BITWISE complement: ~b = -b-1. The previous revision emitted
// CreateNeg (0-b) here, which yields b-c-1 - an off-by-one that silently
// corrupts every consumer of the rewritten subtraction.)
static void subSubstitutionMBA2(BinaryOperator *bo) {
  BinaryOperator *op = BinaryOperator::CreateNot(bo->getOperand(0), "", bo);
  op = BinaryOperator::Create(Instruction::Add, op, bo->getOperand(1), "", bo);
  op = BinaryOperator::CreateNot(op, "", bo);
  bo->replaceAllUsesWith(op);
}

// MBA: a = b & c => a = (b + c) - (b | c)
static void andSubstitutionMBA(BinaryOperator *bo) {
  BinaryOperator *op = BinaryOperator::Create(
      Instruction::Add, bo->getOperand(0), bo->getOperand(1), "", bo);
  BinaryOperator *op1 = BinaryOperator::Create(
      Instruction::Or, bo->getOperand(0), bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Sub, op, op1, "", bo);
  bo->replaceAllUsesWith(op);
}

// MBA: a = b & c => a = (b | c) ^ (b ^ c)
static void andSubstitutionMBA2(BinaryOperator *bo) {
  BinaryOperator *op = BinaryOperator::Create(
      Instruction::Or, bo->getOperand(0), bo->getOperand(1), "", bo);
  BinaryOperator *op1 = BinaryOperator::Create(
      Instruction::Xor, bo->getOperand(0), bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Xor, op, op1, "", bo);
  bo->replaceAllUsesWith(op);
}

// MBA: a = b | c => a = (b + c) - (b & c)
static void orSubstitutionMBA(BinaryOperator *bo) {
  BinaryOperator *op = BinaryOperator::Create(
      Instruction::Add, bo->getOperand(0), bo->getOperand(1), "", bo);
  BinaryOperator *op1 = BinaryOperator::Create(
      Instruction::And, bo->getOperand(0), bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Sub, op, op1, "", bo);
  bo->replaceAllUsesWith(op);
}

// MBA: a = b ^ c => a = 2 * (b | c) - (b + c)
static void xorSubstitutionMBA(BinaryOperator *bo) {
  ConstantInt *co = (ConstantInt *)ConstantInt::get(bo->getType(), 2);
  BinaryOperator *op = BinaryOperator::Create(
      Instruction::Or, bo->getOperand(0), bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Mul, co, op, "", bo);
  BinaryOperator *op1 = BinaryOperator::Create(
      Instruction::Add, bo->getOperand(0), bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Sub, op, op1, "", bo);
  bo->replaceAllUsesWith(op);
}

// MBA: a = b ^ c => a = (b + c) - 2 * (b & c)
static void xorSubstitutionMBA2(BinaryOperator *bo) {
  ConstantInt *co = (ConstantInt *)ConstantInt::get(bo->getType(), 2);
  BinaryOperator *op1 = BinaryOperator::Create(
      Instruction::And, bo->getOperand(0), bo->getOperand(1), "", bo);
  op1 = BinaryOperator::Create(Instruction::Mul, co, op1, "", bo);
  BinaryOperator *op = BinaryOperator::Create(
      Instruction::Add, bo->getOperand(0), bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Sub, op, op1, "", bo);
  bo->replaceAllUsesWith(op);
}

// MBA: a = b ^ c => a = (b | c) - (b & c)
static void xorSubstitutionMBA3(BinaryOperator *bo) {
  BinaryOperator *op = BinaryOperator::Create(
      Instruction::Or, bo->getOperand(0), bo->getOperand(1), "", bo);
  BinaryOperator *op1 = BinaryOperator::Create(
      Instruction::And, bo->getOperand(0), bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Sub, op, op1, "", bo);
  bo->replaceAllUsesWith(op);
}

//===----------------------------------------------------------------------===//
// UP(2): depth-2 composites (MBA identity + De Morgan nesting).
// ~x = -1 ^ x holds exactly, and De Morgan laws hold exactly, so these are
// exact over Z/2^n for every integer width (and element-wise for vectors).
// Each composite mixes the arithmetic and the bitwise domain twice over,
// which requires a simplifier to apply two unrelated rewrite rule families
// in sequence to collapse - pattern matchers that know only one family
// (e.g. "or/and -> xor" or "add/sub -> and/or") get stuck.
//===----------------------------------------------------------------------===//

// MBA2: a = b + c => a = (b ^ c) + 2 * ~(~b | ~c)
static void addSubstitutionMBA2(BinaryOperator *bo) {
  ConstantInt *co = (ConstantInt *)ConstantInt::get(bo->getType(), 2);
  BinaryOperator *nb =
      BinaryOperator::CreateNot(bo->getOperand(0), "", bo);
  BinaryOperator *nc =
      BinaryOperator::CreateNot(bo->getOperand(1), "", bo);
  BinaryOperator *dem =
      BinaryOperator::Create(Instruction::Or, nb, nc, "", bo);
  dem = BinaryOperator::CreateNot(dem, "", bo);
  dem = BinaryOperator::Create(Instruction::Mul, co, dem, "", bo);
  BinaryOperator *op = BinaryOperator::Create(
      Instruction::Xor, bo->getOperand(0), bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Add, op, dem, "", bo);
  bo->replaceAllUsesWith(op);
}

// MBA2: a = b - c => a = (b ^ c) - 2 * ~(b | ~c)
static void subSubstitutionMBA3(BinaryOperator *bo) {
  ConstantInt *co = (ConstantInt *)ConstantInt::get(bo->getType(), 2);
  BinaryOperator *nc =
      BinaryOperator::CreateNot(bo->getOperand(1), "", bo);
  BinaryOperator *dem = BinaryOperator::Create(
      Instruction::Or, bo->getOperand(0), nc, "", bo);
  dem = BinaryOperator::CreateNot(dem, "", bo);
  dem = BinaryOperator::Create(Instruction::Mul, co, dem, "", bo);
  BinaryOperator *op = BinaryOperator::Create(
      Instruction::Xor, bo->getOperand(0), bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Sub, op, dem, "", bo);
  bo->replaceAllUsesWith(op);
}

// MBA2: a = b & c => a = ~((-1 - b) | (-1 - c))
// (-1 - x) is the arithmetic spelling of ~x, so this is De Morgan with the
// inner complements moved into the arithmetic domain (sub from -1).
static void andSubstitutionMBA3(BinaryOperator *bo) {
  Constant *neg1 = ConstantInt::getAllOnesValue(bo->getType());
  BinaryOperator *nb = BinaryOperator::Create(
      Instruction::Sub, neg1, bo->getOperand(0), "", bo);
  BinaryOperator *nc = BinaryOperator::Create(
      Instruction::Sub, neg1, bo->getOperand(1), "", bo);
  BinaryOperator *op =
      BinaryOperator::Create(Instruction::Or, nb, nc, "", bo);
  op = BinaryOperator::CreateNot(op, "", bo);
  bo->replaceAllUsesWith(op);
}

// MBA2: a = b | c => a = (b ^ c) + ~(~b | ~c)
static void orSubstitutionMBA2(BinaryOperator *bo) {
  BinaryOperator *nb =
      BinaryOperator::CreateNot(bo->getOperand(0), "", bo);
  BinaryOperator *nc =
      BinaryOperator::CreateNot(bo->getOperand(1), "", bo);
  BinaryOperator *dem =
      BinaryOperator::Create(Instruction::Or, nb, nc, "", bo);
  dem = BinaryOperator::CreateNot(dem, "", bo);
  BinaryOperator *op = BinaryOperator::Create(
      Instruction::Xor, bo->getOperand(0), bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Add, op, dem, "", bo);
  bo->replaceAllUsesWith(op);
}

// MBA2: a = b ^ c => a = (b | c) - ~(~b | ~c)
static void xorSubstitutionMBA4(BinaryOperator *bo) {
  BinaryOperator *nb =
      BinaryOperator::CreateNot(bo->getOperand(0), "", bo);
  BinaryOperator *nc =
      BinaryOperator::CreateNot(bo->getOperand(1), "", bo);
  BinaryOperator *dem =
      BinaryOperator::Create(Instruction::Or, nb, nc, "", bo);
  dem = BinaryOperator::CreateNot(dem, "", bo);
  BinaryOperator *op = BinaryOperator::Create(
      Instruction::Or, bo->getOperand(0), bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Sub, op, dem, "", bo);
  bo->replaceAllUsesWith(op);
}

// MBA2: a = b ^ c => a = (b + c) - 2 * ~(~b | ~c)
static void xorSubstitutionMBA5(BinaryOperator *bo) {
  ConstantInt *co = (ConstantInt *)ConstantInt::get(bo->getType(), 2);
  BinaryOperator *nb =
      BinaryOperator::CreateNot(bo->getOperand(0), "", bo);
  BinaryOperator *nc =
      BinaryOperator::CreateNot(bo->getOperand(1), "", bo);
  BinaryOperator *dem =
      BinaryOperator::Create(Instruction::Or, nb, nc, "", bo);
  dem = BinaryOperator::CreateNot(dem, "", bo);
  dem = BinaryOperator::Create(Instruction::Mul, co, dem, "", bo);
  BinaryOperator *op = BinaryOperator::Create(
      Instruction::Add, bo->getOperand(0), bo->getOperand(1), "", bo);
  op = BinaryOperator::Create(Instruction::Sub, op, dem, "", bo);
  bo->replaceAllUsesWith(op);
}
