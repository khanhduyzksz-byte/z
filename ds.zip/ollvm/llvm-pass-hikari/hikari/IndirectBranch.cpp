// For open-source license, please refer to
// [License](https://github.com/HikariObfuscator/Hikari/wiki/License).
//===----------------------------------------------------------------------===//

#include "IndirectBranch.h"
#include "CryptoUtils.h"
#include "Utils.h"

bool IndirectBranch::initialize(Module &M) {
  PassBuilder PB;
  FunctionAnalysisManager FAM;
  FunctionPassManager FPM;
  PB.registerFunctionAnalyses(FAM);
  FPM.addPass(LowerSwitchPass());

  SmallVector<BasicBlock *, 32> AllBBs;
  for (Function* pF : to_obf_funcs) {
    Function& F = *pF;
    // See https://github.com/61bcdefg/Hikari-LLVM15/issues/32
    FPM.run(F, FAM);

    if (EncryptJumpTarget)
      encmap[&F] = ConstantInt::get(
          Type::getInt32Ty(M.getContext()),
          cryptoutils->get_range(UINT8_MAX, UINT16_MAX * 2) * 4);
    for (BasicBlock &BB : F)
      if (!BB.isEntryBlock())
        AllBBs.emplace_back(&BB);
  }
  // UP: assign shuffled (non-linear) table indices. The legacy pass assigned
  // sequential indices, which made the dispatch table trivially reversible.
  SmallVector<unsigned long long, 32> perm(AllBBs.size());
  for (unsigned long long j = 0; j < perm.size(); j++)
    perm[j] = j;
  for (size_t j = perm.size(); j > 1; j--)
    std::swap(perm[j - 1], perm[cryptoutils->get_range(j)]);
  SmallVector<Constant *, 32> BBs(AllBBs.size());
  for (unsigned long long j = 0; j < AllBBs.size(); j++) {
    indexmap[AllBBs[j]] = perm[j];
    BBs[perm[j]] =
        EncryptJumpTarget
            ? ConstantExpr::getGetElementPtr(
                  Type::getInt8Ty(M.getContext()),
                  ConstantExpr::getBitCast(
                      BlockAddress::get(AllBBs[j]),
                      Type::getInt8Ty(M.getContext())->getPointerTo()),
                  encmap[AllBBs[j]->getParent()])
            : BlockAddress::get(AllBBs[j]);
  }
  if (to_obf_funcs.size()) {
    ArrayType *AT = ArrayType::get(
        Type::getInt8Ty(M.getContext())->getPointerTo(), BBs.size());
    Constant *BlockAddressArray =
        ConstantArray::get(AT, ArrayRef<Constant *>(BBs));
    // UP: randomized table symbol name (was IndirectBranchingGlobalTable)
    GlobalTable = new GlobalVariable(
        M, AT, false, GlobalValue::LinkageTypes::PrivateLinkage,
        BlockAddressArray, getRandomName("t"));
    appendToCompilerUsed(M, {GlobalTable});
  }
  this->initialized = true;
  return true;
}

bool IndirectBranch::runOnFunction(Function &Func) {
  Module *M = Func.getParent();
  if (!this->initialized)
    initialize(*M);
  if (std::find(to_obf_funcs.begin(), to_obf_funcs.end(), &Func) ==
      to_obf_funcs.end())
    return false;
  errs() << "Running IndirectBranch On " << Func.getName() << "\n";
  SmallVector<BranchInst *, 32> BIs;
  for (Instruction &Inst : instructions(Func))
    if (BranchInst *BI = dyn_cast<BranchInst>(&Inst))
      BIs.emplace_back(BI);

  Type *Int8Ty = Type::getInt8Ty(M->getContext());
  Type *Int32Ty = Type::getInt32Ty(M->getContext());
  Type *Int8PtrTy = Type::getInt8Ty(M->getContext())->getPointerTo();

  Value *zero = ConstantInt::get(Int32Ty, 0);

  IRBuilder<NoFolder> *IRBEntry =
      new IRBuilder<NoFolder>(&Func.getEntryBlock().front());
  for (BranchInst *BI : BIs) {
    if (UseStack &&
        IRBEntry->GetInsertPoint() !=
            (BasicBlock::iterator)Func.getEntryBlock().front())
      IRBEntry->SetInsertPoint(Func.getEntryBlock().getTerminator());
    IRBuilder<NoFolder> *IRBBI = new IRBuilder<NoFolder>(BI);
    SmallVector<BasicBlock *, 16> BBs;
    // We use the condition's evaluation result to generate the GEP
    // instruction  False evaluates to 0 while true evaluates to 1.  So here
    // we insert the false block first
    if (BI->isConditional() && !BI->getSuccessor(1)->isEntryBlock())
      BBs.emplace_back(BI->getSuccessor(1));
    if (!BI->getSuccessor(0)->isEntryBlock())
      BBs.emplace_back(BI->getSuccessor(0));

    GlobalVariable *LoadFrom = nullptr;
    if (BI->isConditional() ||
        indexmap.find(BI->getSuccessor(0)) == indexmap.end()) {
      ArrayType *AT = ArrayType::get(Int8PtrTy, BBs.size());
      SmallVector<Constant *, 16> BlockAddresses;
      for (BasicBlock *BB : BBs)
        BlockAddresses.emplace_back(
            EncryptJumpTarget ? ConstantExpr::getGetElementPtr(
                                        Int8Ty,
                                        ConstantExpr::getBitCast(
                                            BlockAddress::get(BB), Int8PtrTy),
                                        encmap[&Func])
                                  : BlockAddress::get(BB));
      // Create a new GV
      Constant *BlockAddressArray =
          ConstantArray::get(AT, ArrayRef<Constant *>(BlockAddresses));
      // UP: randomized local table symbol
      LoadFrom = new GlobalVariable(
          *M, AT, false, GlobalValue::LinkageTypes::PrivateLinkage,
          BlockAddressArray, getRandomName("lt"));
      appendToCompilerUsed(*Func.getParent(), {LoadFrom});
    } else {
      // UP: direct pointer instead of the fixed-name lookup
      LoadFrom = this->GlobalTable;
    }
    AllocaInst *LoadFromAI = nullptr;
    if (UseStack) {
      LoadFromAI = IRBEntry->CreateAlloca(LoadFrom->getType());
      IRBEntry->CreateStore(LoadFrom, LoadFromAI);
    }
    Value *index, *RealIndex = nullptr;
    if (BI->isConditional()) {
      Value *condition = BI->getCondition();
      Value *zext = IRBBI->CreateZExt(condition, Int32Ty);
      if (UseStack) {
        AllocaInst *condAI = IRBEntry->CreateAlloca(Int32Ty);
        IRBBI->CreateStore(zext, condAI);
        index = condAI;
      } else {
        index = zext;
      }
      RealIndex = index;
    } else {
      Value *indexval = nullptr;
      ConstantInt *IndexEncKey =
          EncryptJumpTarget ? cast<ConstantInt>(ConstantInt::get(
                                      Int32Ty, cryptoutils->get_uint32_t()))
                                : nullptr;
      if (EncryptJumpTarget) {
        GlobalVariable *indexgv = new GlobalVariable(
            *M, Int32Ty, false, GlobalValue::LinkageTypes::PrivateLinkage,
            ConstantInt::get(IndexEncKey->getType(),
                              IndexEncKey->getValue() ^
                                  indexmap[BI->getSuccessor(0)]),
            getRandomName("ix"));
        appendToCompilerUsed(*M, {indexgv});
        indexval = (UseStack ? IRBEntry : IRBBI)
                        ->CreateLoad(indexgv->getValueType(), indexgv);
      } else {
        indexval = ConstantInt::get(Int32Ty, indexmap[BI->getSuccessor(0)]);
        if (UseStack) {
          AllocaInst *indexAI = IRBEntry->CreateAlloca(Int32Ty);
          IRBEntry->CreateStore(indexval, indexAI);
          indexval = IRBBI->CreateLoad(indexAI->getAllocatedType(), indexAI);
        }
      }
      index = indexval;
      RealIndex = EncryptJumpTarget ? IRBBI->CreateXor(index, IndexEncKey)
                                        : index;
    }
    Value *LI, *enckeyLoad, *gepptr = nullptr;
    if (UseStack) {
      LoadInst *LILoadFrom =
          IRBBI->CreateLoad(LoadFrom->getType(), LoadFromAI);
      Value *GEP = IRBBI->CreateGEP(
          LoadFrom->getValueType(), LILoadFrom,
          {zero, BI->isConditional() ? IRBBI->CreateLoad(Int32Ty, RealIndex)
                                      : RealIndex});
      if (!EncryptJumpTarget)
        LI = IRBBI->CreateLoad(Int8PtrTy, GEP,
                                "IndirectBranchingTargetAddress");
      else
        gepptr = IRBBI->CreateLoad(Int8PtrTy, GEP);
    } else {
      Value *GEP = IRBBI->CreateGEP(LoadFrom->getValueType(), LoadFrom,
                                    {zero, RealIndex});
      if (!EncryptJumpTarget)
        LI = IRBBI->CreateLoad(Int8PtrTy, GEP,
                                "IndirectBranchingTargetAddress");
      else
        gepptr = IRBBI->CreateLoad(Int8PtrTy, GEP);
    }
    if (EncryptJumpTarget) {
      ConstantInt *encenckey = cast<ConstantInt>(
          ConstantInt::get(Int32Ty, cryptoutils->get_uint32_t()));
      GlobalVariable *enckeyGV = new GlobalVariable(
          *M, Int32Ty, false, GlobalValue::LinkageTypes::PrivateLinkage,
          ConstantInt::get(Int32Ty,
                            encenckey->getValue() ^ encmap[&Func]->getValue()),
          getRandomName("ek"));
      appendToCompilerUsed(*M, enckeyGV);
      enckeyLoad = IRBBI->CreateXor(
          IRBBI->CreateLoad(enckeyGV->getValueType(), enckeyGV), encenckey);
      LI =
          IRBBI->CreateGEP(Int8Ty, gepptr, IRBBI->CreateSub(zero, enckeyLoad),
                            "IndirectBranchingTargetAddress");
    }
    IndirectBrInst *indirBr = IndirectBrInst::Create(LI, BBs.size());
    for (BasicBlock *BB : BBs)
      indirBr->addDestination(BB);
    ReplaceInstWithInst(BI, indirBr);
  }
  shuffleBasicBlocks(Func);
  return true;
}

void IndirectBranch::shuffleBasicBlocks(Function &F) {
  SmallVector<BasicBlock *, 32> blocks;
  for (BasicBlock &block : F)
    if (!block.isEntryBlock())
      blocks.emplace_back(&block);

  if (blocks.size() < 2)
    return;

  for (size_t i = blocks.size() - 1; i > 0; i--)
    std::swap(blocks[i], blocks[cryptoutils->get_range(i + 1)]);

  Function::iterator fi = F.begin();
  for (BasicBlock *block : blocks) {
    fi++;
    block->moveAfter(&*(fi));
  }
}

