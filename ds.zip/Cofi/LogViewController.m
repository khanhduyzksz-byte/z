//
//  LogViewController.m
//  Cofi
//

#import "LogViewController.h"
#import "LogTextView.h"
#import "UITheme.h"
#import <sys/utsname.h>

@interface LogViewController ()
@property (nonatomic, strong) UILabel *bannerLabel;
@property (nonatomic, strong) LogTextView *logView;
@end

@implementation LogViewController

// Console background 3105: light #F2F2F7 / dark #1C1C1E (consoleBackground).
static inline UIColor *DSConsoleColor(void) {
    return [UIColor colorWithDynamicProvider:^UIColor *(UITraitCollection *traits) {
        if (traits.userInterfaceStyle == UIUserInterfaceStyleDark)
            return [UIColor colorWithRed:0.11 green:0.11 blue:0.12 alpha:1.0]; // #1C1C1E
        return [UIColor colorWithRed:0.949 green:0.949 blue:0.969 alpha:1.0]; // #F2F2F7
    }];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Log";
    self.view.backgroundColor = DSConsoleColor();

    UIBarButtonItem *copyBtn = [[UIBarButtonItem alloc]
        initWithImage:[UIImage systemImageNamed:@"doc.on.doc"]
                style:UIBarButtonItemStylePlain
               target:self
               action:@selector(copyAllLog)];
    copyBtn.tintColor = UIAccent();

    UIBarButtonItem *shareBtn = [[UIBarButtonItem alloc]
        initWithImage:[UIImage systemImageNamed:@"square.and.arrow.up"]
                style:UIBarButtonItemStylePlain
               target:self
               action:@selector(shareLogFile)];
    shareBtn.tintColor = UIAccent();

    self.navigationItem.rightBarButtonItems = @[shareBtn, copyBtn];

    _bannerLabel = [[UILabel alloc] init];
    _bannerLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _bannerLabel.numberOfLines = 0;
    _bannerLabel.font = [UIFont monospacedSystemFontOfSize:11.5 weight:UIFontWeightRegular];
    _bannerLabel.textColor = UIColor.secondaryLabelColor;
    _bannerLabel.backgroundColor = UIColor.systemBackgroundColor; // thẻ trắng 3105
    _bannerLabel.textAlignment = NSTextAlignmentCenter;
    _bannerLabel.attributedText = [self buildBannerText];
    _bannerLabel.layer.cornerRadius = 12;
    _bannerLabel.layer.borderWidth = 0.5;
    _bannerLabel.layer.borderColor = [UIColor colorWithWhite:0.0 alpha:0.08].CGColor;
    _bannerLabel.clipsToBounds = YES;
    [self.view addSubview:_bannerLabel];

    UIView *separator = [[UIView alloc] init];
    separator.translatesAutoresizingMaskIntoConstraints = NO;
    separator.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.08];
    [self.view addSubview:separator];

    _logView = [[LogTextView alloc] initWithFrame:CGRectZero];
    _logView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:_logView];

    [NSLayoutConstraint activateConstraints:@[
        [_bannerLabel.topAnchor      constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:12],
        [_bannerLabel.leadingAnchor  constraintEqualToAnchor:self.view.safeAreaLayoutGuide.leadingAnchor constant:12],
        [_bannerLabel.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-12],

        [separator.topAnchor      constraintEqualToAnchor:_bannerLabel.bottomAnchor constant:12],
        [separator.leadingAnchor  constraintEqualToAnchor:self.view.leadingAnchor],
        [separator.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [separator.heightAnchor   constraintEqualToConstant:0.5],

        [_logView.topAnchor      constraintEqualToAnchor:separator.bottomAnchor],
        [_logView.bottomAnchor   constraintEqualToAnchor:self.view.bottomAnchor],
        [_logView.leadingAnchor  constraintEqualToAnchor:self.view.leadingAnchor],
        [_logView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
    ]];
}

- (void)copyAllLog {
    NSString *snapshot = log_inapp_buffer_snapshot();
    if (snapshot.length == 0) snapshot = @"(empty)";
    [UIPasteboard generalPasteboard].string = snapshot;

    UILabel *toast = [[UILabel alloc] init];
    toast.text = @"Log copied";
    toast.font = [UIFont boldSystemFontOfSize:13];
    toast.layer.cornerRadius = 8;
    toast.clipsToBounds = YES;
    if (self.traitCollection.userInterfaceStyle == UIUserInterfaceStyleDark) {
        toast.textColor = [UIColor colorWithWhite:0.10 alpha:1.0];
        toast.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.92];
    } else {
        toast.textColor = [UIColor whiteColor];
        toast.backgroundColor = [UIColor colorWithWhite:0.10 alpha:0.92];
    }
    [toast sizeToFit];
    CGFloat w = toast.bounds.size.width + 32;
    toast.frame = CGRectMake((self.view.bounds.size.width - w) / 2, self.view.safeAreaInsets.top + 60, w, 32);
    [self.view addSubview:toast];
    [UIView animateWithDuration:0.3 delay:1.0 options:0 animations:^{
        toast.alpha = 0;
    } completion:^(BOOL finished) {
        [toast removeFromSuperview];
    }];
}

- (void)shareLogFile {
    NSString *sessionPath = log_most_recent_session_path();
    NSMutableArray *items = [NSMutableArray array];

    if (sessionPath && [[NSFileManager defaultManager] fileExistsAtPath:sessionPath]) {
        [items addObject:[NSURL fileURLWithPath:sessionPath]];
    } else {
        NSString *snapshot = log_inapp_buffer_snapshot();
        if (snapshot.length == 0) snapshot = @"(empty)";
        [items addObject:snapshot];
    }

    UIActivityViewController *avc = [[UIActivityViewController alloc] initWithActivityItems:items
                                                                      applicationActivities:nil];
    avc.popoverPresentationController.barButtonItem = self.navigationItem.rightBarButtonItems.firstObject;
    [self presentViewController:avc animated:YES completion:nil];
}

- (NSAttributedString *)buildBannerText {
    NSBundle *b = [NSBundle mainBundle];
    NSDictionary *info = b.infoDictionary;
    NSString *shortVer = info[@"CFBundleShortVersionString"] ?: @"?";
    NSString *build = info[@"CFBundleVersion"] ?: @"?";

    struct utsname u = {0};
    const char *machine = "device";
    if (uname(&u) == 0 && u.machine[0])
        machine = u.machine;
    NSString *ios = UIDevice.currentDevice.systemVersion ?: @"?";

    NSMutableParagraphStyle *center = [[NSMutableParagraphStyle alloc] init];
    center.alignment = NSTextAlignmentCenter;
    center.lineSpacing = 4.0;

    UIColor *detailFontColor = UIColor.secondaryLabelColor;
    UIFont *detailFont = [UIFont monospacedSystemFontOfSize:11.5 weight:UIFontWeightRegular];

    NSMutableAttributedString *attr = [[NSMutableAttributedString alloc] init];

    NSString *line2 = [NSString stringWithFormat:@"External for Free Fire | Version: %@ (%@)\n%s • iOS %@",
                       shortVer, build, machine, ios];
    [attr appendAttributedString:[[NSAttributedString alloc] initWithString:line2 attributes:@{
        NSFontAttributeName: detailFont,
        NSForegroundColorAttributeName: detailFontColor,
        NSParagraphStyleAttributeName: center,
    }]];

    return attr;
}

@end
