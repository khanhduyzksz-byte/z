#import "HeaderAPI.h"
#import "DuyServer.h"
#import "../Core/OffsetRegistry.h"   /* Task 17 — runtime offset registry (server-gated) */

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <stdlib.h>

// ======================================================================
// khanhduy — License flow V2 + Full-screen key gate (UIKey).
//
// PHIẾN BẢN NÀY (Phase 1):
//   • TOÀN BỘ anti-tamper cũ đã LOẠI BỎ (theo yêu cầu): watchdog canary,
//     token đa kho q1..q5 + mirror vk4 + marker dy9, IMP baseline 15 method,
//     dò môi trường DYLD/frida/debugger, exit đa đường, constructor reassert,
//     vm_exec/trampoline obfuscation. Anti sẽ thêm lại ở phase 2.
//   • Luồng UI GIỮ NGUYÊN: màn đen → loading → nhập key / maintenance /
//     success → mở khóa. Người dùng key hợp lệ trải nghiệm như cũ.
//   • Luồng verify NÂNG CẤP server-authoritative:
//       BOOT → hello (challenge nonce_s) → auth (PoP bằng keypair Secure
//       Enclave) → LEASE CÓ CHỮ KÝ verify 11 bước → AUTHORIZED → renew
//       ngắn hạn (jitter) + grace có ký → revoke/expired → khóa.
//   • Mọi phản hồi phải verify chữ ký ECDSA P-256 bằng public key nhúng —
//     MITM/proxy giả {status:true} sẽ KHÔNG qua được verify.
//   • Không exit() bừa bãi: chỉ forceExit khi server ký force_exit=1.
//     Lỗi mạng → gate hiển thị + retry backoff (fail-closed, không crash).
//   • License key lưu Keychain (không còn NSUserDefaults).
// ======================================================================

@interface khanhduy : NSObject
@property (nonatomic, strong) NSString *contactLink;
@property (nonatomic, assign) BOOL isMaintenance;
@property (nonatomic, strong) NSMutableDictionary *memoryGap;
+ (instancetype)sharedInstance;
- (void)startProcess;
@end

// ======================================================================
// Full-screen black key gate (màn chắn nhập key) — giữ nguyên cơ chế V1:
// gate là rootViewController của cửa sổ CHÍNH của app.
// ======================================================================
static UIWindow *g_kdy_tmp_window = nil;       /* cửa sổ đen tạm lúc launch */
static UIWindow *g_kdy_app_window = nil;       /* cửa sổ CHÍNH của app (storyboard) */
static UIViewController *g_kdy_vc = nil;        /* VC màn key */
static UIViewController *g_kdy_orig_root = nil; /* rootVC gốc của app */
static UITextField *g_kdy_input = nil;
static UIView *g_kdy_group = nil;               /* nhóm input+nút — hiệu ứng rung */
static UILabel *g_kdy_status = nil;
static int g_kdy_retry_gen = 0;
static int g_kdy_attach_tries = 0;

/* V2 protocol state (flow-level, không phải verified flag) */
static NSString *g_kdy_nonce_s = nil;           /* challenge từ hello */
static int64_t  g_kdy_nonce_s_ts = 0;           /* lúc nhận challenge */
static int      g_kdy_hello_gen = 0;            /* chống chồng hello retry */
static int      g_kdy_renew_gen = 0;            /* chống chồng renew timer */
static int      g_kdy_net_miss = 0;             /* lỗi mạng liên tiếp (renew) */
static int      g_kdy_verify_fail = 0;          /* verify sai liên tiếp (an ninh) */
static int64_t  g_kdy_last_beat_ms = 0;         /* debounce renew 90s */
static BOOL     g_kdy_observer_added = NO;
static BOOL     g_kdy_in_auth = NO;             /* chống double-tap LOGIN */
static NSURLSession *g_kdy_session = nil;       /* session timeout riêng */
static NSInteger g_kdy_hello_fails = 0;         /* hello thất bại liên tiếp */
static NSString *g_kdy_error_reason = nil;      /* lý do lần thất bại cuối (màn lỗi) */
static int64_t  g_kdy_last_challenge_re = 0;    /* lần cuối auto-retry khi Challenge expired */
static BOOL     g_kdy_in_offsets_fetch = NO;  /* Task 17 — chống double fetch offset */
static int      g_kdy_offsets_gen = 0;        /* Task 17 — thế hệ fetch (hủy retry cũ) */
static int      g_kdy_offsets_fails = 0;      /* Task 17 — fetch offset fail liên tiếp */

/* Task 18 — kết quả kiểm tra key lúc bấm "Activate ESP" (định nghĩa ở đây,
 * khai báo extern "C" trong DuyServer.h — ESPInstaller lắng nghe).
 * Offset CHỈ được server cấp qua lượt check này; auth/renew KHÔNG tự fetch. */
NSString *kdy_offsets_check_ok   = @"kdy_offsets_check_ok";
NSString *kdy_offsets_check_deny = @"kdy_offsets_check_deny";

@interface khanhduy ()
- (void)gate_show;
- (BOOL)gate_attach;
- (void)kdy_drop_tmp_window;
- (void)gate_state_loading:(NSString *)msg;
- (void)gate_state_error:(NSString *)reason;
- (void)gate_state_input;
- (void)gate_state_success:(NSString *)info;
- (void)gate_state_maintenance;
- (void)gate_dismiss;
- (void)gate_set_status:(NSString *)msg color:(UIColor *)color shake:(BOOL)shake;
- (NSString *)localizedServerMessage:(NSString *)raw;
- (void)gate_login_tapped;
- (void)gate_contact_tapped;
- (void)gate_exit_tapped;
- (void)gate_bg_tapped;
- (UIViewController *)gate_presenter;
/* V2 flow */
- (void)kdy_hello;
- (void)kdy_hello_retry:(double)delay;
- (void)kdy_hello_fail:(NSString *)reason baseDelay:(double)baseDelay;
- (void)kdy_retry_from_error;
- (void)checkKey:(NSString *)key isAuto:(BOOL)isAuto;
- (void)kdy_execute_auth:(NSString *)key isAuto:(BOOL)isAuto;
- (void)kdy_handle_auth_reject:(NSString *)message key:(NSString *)key forceExit:(BOOL)forceExit;
- (void)handleInvalidKey:(NSString *)key message:(NSString *)msg;
- (void)kdy_beat_start;
- (void)kdy_beat_schedule:(double)sec;
- (void)kdy_beat_fire;
- (void)kdy_renew_now;
/* Task 17/18 — fetch offset từ server. Offsets chỉ được cấp khi bấm
 * "Activate ESP" (kdy_fetch_offsets_check — force, hỏi key TƯƠI);
 * kdy_fetch_offsets (passive) chỉ dùng cho retry sau lỗi mạng. */
- (void)kdy_fetch_offsets;
- (void)kdy_fetch_offsets_check;
- (void)kdy_fetch_offsets_run:(BOOL)force;
- (void)kdy_offsets_retry_later:(double)sec;
- (void)kdy_handle_lease_reject:(NSString *)message;
- (void)kdy_lockdown:(NSString *)reason;
- (void)kdy_restart_auth;
- (void)kdy_resume_observe;
- (void)kdy_resume_tick;
- (void)kdy_reassert_gate;
- (void)showAlert:(NSString *)title message:(NSString *)message retry:(BOOL)retry;
- (void)forceExitApp:(NSString *)reason;
- (void)postLicense:(NSDictionary *)body action:(NSString *)action
         sentNonce:(NSString *)sentNonce
         completion:(void (^)(NSDictionary *json, NSError *error))done;
- (NSURLSession *)netSession;
@end

// ----------------------------------------------------------------------
// VISUAL KIT — 3105 v2 style (theme ThreeOneOSFive / YangJiiii-3105):
// nen sang #F2F2F7, the TRANG bo goc lon + vien hairline, icon SF Symbols
// xam/accent cam, accent cam #D96B33, nut phang — KHONG gradient, KHONG glow.
// Toan bo dung frame + autoresizing nhu cu — khong can AutoLayout.
// ----------------------------------------------------------------------
static inline UIColor *kdy_gc(uint32_t rgb, CGFloat a) {
    return [UIColor colorWithRed:((rgb >> 16) & 0xFF) / 255.0
                           green:((rgb >> 8) & 0xFF) / 255.0
                            blue:(rgb & 0xFF) / 255.0 alpha:a];
}

/* Nen sang chung cho moi man gate — #F2F2F7 (grouped background iOS) */
static UIView *kdy_gate_background(CGRect b) {
    UIView *bg = [[UIView alloc] initWithFrame:b];
    bg.backgroundColor = kdy_gc(0xF2F2F7, 1.0);
    bg.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    return bg;
}

/* Badge icon kieu 3105 (AppRowIcon): o vuong bo mem, nen tint 12%, icon tint mau */
static UIView *kdy_gate_badge(NSString *symbolName, NSString *glyph, UIColor *color, CGFloat size) {
    UIView *v = [[UIView alloc] initWithFrame:CGRectMake(0, 0, size, size)];
    v.backgroundColor = [color colorWithAlphaComponent:0.12];
    v.layer.cornerRadius = size * 0.24;

    BOOL ok = NO;
    if (@available(iOS 13.0, *)) {
        UIImageSymbolConfiguration *cfg =
            [UIImageSymbolConfiguration configurationWithPointSize:size * 0.40
                                                            weight:UIImageSymbolWeightMedium];
        UIImage *img = [UIImage systemImageNamed:symbolName withConfiguration:cfg];
        if (img) {
            UIImageView *iv = [[UIImageView alloc] initWithImage:img];
            iv.tintColor = color;
            iv.center = CGPointMake(size / 2.0, size / 2.0);
            [v addSubview:iv];
            ok = YES;
        }
    }
    if (!ok) {
        UILabel *l = [[UILabel alloc] initWithFrame:v.bounds];
        l.text = glyph;
        l.textColor = color;
        l.font = [UIFont systemFontOfSize:size * 0.40 weight:UIFontWeightSemibold];
        l.textAlignment = NSTextAlignmentCenter;
        [v addSubview:l];
    }
    return v;
}

/* Logo — o vuong cam phang chu FF trang (nhu app icon 3105, khong glow) */
static UIView *kdy_gate_logo(CGFloat size) {
    UIView *v = [[UIView alloc] initWithFrame:CGRectMake(0, 0, size, size)];
    v.backgroundColor = kdy_gc(0xD96B33, 1.0);
    v.layer.cornerRadius = size * 0.24;
    UILabel *l = [[UILabel alloc] initWithFrame:v.bounds];
    l.text = @"FF";
    l.textColor = [UIColor whiteColor];
    l.font = [UIFont systemFontOfSize:size * 0.34 weight:UIFontWeightHeavy];
    l.textAlignment = NSTextAlignmentCenter;
    [v addSubview:l];
    return v;
}

/* Style the trang dung chung (content card 3105) */
static void kdy_gate_card(UIView *v) {
    v.backgroundColor = [UIColor whiteColor];
    v.layer.cornerRadius = 20.0;
    v.layer.borderWidth = 0.5;
    v.layer.borderColor = [UIColor colorWithWhite:0.0 alpha:0.08].CGColor;
}

/* Nut phang 3105: filled = cam trang chu; outline = trang + vien hairline */
static UIButton *kdy_gate_button(NSString *title, CGRect frame, BOOL filled) {
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = frame;
    btn.layer.cornerRadius = 14.0;
    [btn setTitle:title forState:UIControlStateNormal];
    if (filled) {
        btn.backgroundColor = kdy_gc(0xD96B33, 1.0);
        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        btn.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightSemibold];
    } else {
        btn.backgroundColor = [UIColor whiteColor];
        btn.layer.borderWidth = 0.5;
        btn.layer.borderColor = [UIColor colorWithWhite:0.0 alpha:0.12].CGColor;
        [btn setTitleColor:kdy_gc(0x1C1C1E, 1.0) forState:UIControlStateNormal];
        btn.titleLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightSemibold];
    }
    return btn;
}



@implementation khanhduy

#pragma mark - Boot

+ (void)load {
    /* Hiện màn đen phủ toàn app gần như ngay lập tức (như V1) */
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.05 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        [[khanhduy sharedInstance] gate_show];
    });

    /* Khởi động luồng license V2 sau khi UI sẵn sàng */
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.6 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        [[khanhduy sharedInstance] startProcess];
    });
}

+ (instancetype)sharedInstance {
    static khanhduy *sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[khanhduy alloc] init];
        sharedInstance.contactLink = @"";
        sharedInstance.memoryGap = [NSMutableDictionary dictionary];
    });
    return sharedInstance;
}

- (void)startProcess {
    /* 1. Migrate dữ liệu V1 (key trong NSUserDefaults → Keychain) */
    [[LicenseCore sharedCore] migrateLegacyDefaults];

    /* 2. BOOT → NET_INIT (bắt buộc qua state machine) */
    LicenseCore *core = [LicenseCore sharedCore];
    [core transitionTo:LicenseStateNetInit];

    /* 3. hello — xin challenge + contact + maintenance */
    [self kdy_hello];

    /* 4. Reassert tick — chạy mãi, chỉ có tác dụng khi chưa authorized */
    [self kdy_reassert_tick];
}

- (UIViewController *)getTopViewController {
    UIViewController *resultVC = nil;
    UIWindow *foundWindow = nil;
    UIApplication *sharedApp = [UIApplication sharedApplication];

    if (@available(iOS 13.0, *)) {
        for (UIScene *scene in sharedApp.connectedScenes) {
            if ([scene isKindOfClass:[UIWindowScene class]]
                && scene.activationState == UISceneActivationStateForegroundActive) {
                UIWindowScene *ws = (UIWindowScene *)scene;
                for (UIWindow *w in ws.windows) {
                    if (w.isKeyWindow) {
                        foundWindow = w;
                        break;
                    }
                }
            }
            if (foundWindow) break;
        }
    }
    if (!foundWindow) {
        for (UIWindow *window in sharedApp.windows) {
            if (window.isKeyWindow) {
                foundWindow = window;
                break;
            }
        }
        if (!foundWindow && sharedApp.windows.count > 0) {
            foundWindow = sharedApp.windows.firstObject;
        }
    }
    resultVC = foundWindow.rootViewController;
    while (resultVC.presentedViewController) {
        resultVC = resultVC.presentedViewController;
    }
    return resultVC;
}

#pragma mark - V2 Network (POST JSON, timeout hữu hạn, không block main)

- (NSURLSession *)netSession {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSURLSessionConfiguration *cfg = [NSURLSessionConfiguration defaultSessionConfiguration];
        cfg.timeoutIntervalForRequest = 12.0;     /* request timeout hữu hạn */
        cfg.timeoutIntervalForResource = 20.0;
        cfg.waitsForConnectivity = NO;
        g_kdy_session = [NSURLSession sessionWithConfiguration:cfg];
    });
    return g_kdy_session;
}

- (void)postLicense:(NSDictionary *)body action:(NSString *)action
         sentNonce:(NSString *)sentNonce
         completion:(void (^)(NSDictionary *json, NSError *error))done {
    (void)sentNonce;

    NSURL *url = [NSURL URLWithString:kBaseAPIURL];
    if (!url || ![url.scheme isEqualToString:@"https"]) {
        /* Release bắt buộc HTTPS — không fallback HTTP */
        done(nil, [NSError errorWithDomain:@"khanhduy.license" code:-1
                                   userInfo:@{NSLocalizedDescriptionKey:@"Endpoint phải là HTTPS"}]);
        return;
    }

    NSError *serErr = nil;
    NSData *payload = [NSJSONSerialization dataWithJSONObject:body options:0 error:&serErr];
    if (!payload || serErr) {
        done(nil, serErr ?: [NSError errorWithDomain:@"khanhduy.license" code:-2
                                            userInfo:@{NSLocalizedDescriptionKey:@"Serialize lỗi"}]);
        return;
    }

    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url];
    req.HTTPMethod = @"POST";
    req.HTTPBody = payload;
    [req setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [req setValue:@"no-store" forHTTPHeaderField:@"Cache-Control"];
    req.cachePolicy = NSURLRequestReloadIgnoringLocalCacheData;

    NSURLSessionDataTask *task = [[self netSession] dataTaskWithRequest:req
        completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
            if (error) {
                dispatch_async(dispatch_get_main_queue(), ^{ done(nil, error); });
                return;
            }
            NSHTTPURLResponse *http = nil;
            if ([response isKindOfClass:[NSHTTPURLResponse class]]) {
                http = (NSHTTPURLResponse *)response;
            }
            if (!http || http.statusCode != 200 || !data || data.length == 0) {
                long code = (http ? (long)http.statusCode : 0);
                NSString *detail = (code > 0)
                    ? [NSString stringWithFormat:@"server trả HTTP %ld", code]
                    : @"phản hồi rỗng";
                dispatch_async(dispatch_get_main_queue(), ^{
                    done(nil, [NSError errorWithDomain:@"khanhduy.license" code:-3
                                               userInfo:@{NSLocalizedDescriptionKey:
                                                   [NSString stringWithFormat:@"Server phản hồi không hợp lệ (%@)", detail]}]);
                });
                return;
            }
            id parsed = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
            if (![parsed isKindOfClass:[NSDictionary class]]) {
                /* HTML (trang chặn Cloudflare / lỗi PHP) → gợi ý theo content-type */
                NSString *ct = [http.allHeaderFields[@"Content-Type"] isKindOfClass:[NSString class]]
                    ? http.allHeaderFields[@"Content-Type"] : @"";
                NSString *detail = [ct containsString:@"html"]
                    ? @"server trả về trang HTML thay vì JSON (bị chặn hoặc lỗi PHP)"
                    : @"định dạng JSON không hợp lệ";
                dispatch_async(dispatch_get_main_queue(), ^{
                    done(nil, [NSError errorWithDomain:@"khanhduy.license" code:-4
                                               userInfo:@{NSLocalizedDescriptionKey:detail}]);
                });
                return;
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                done((NSDictionary *)parsed, nil);
            });
        }];
    [task resume];
}

#pragma mark - hello (challenge)

- (void)kdy_hello {
    int gen = ++g_kdy_hello_gen;
    LicenseCore *core = [LicenseCore sharedCore];

    /* Pre-check cấu hình — không gọi server nếu token chưa thay.
     * (Server sẽ force-exit cho token sai — báo trước cho user dễ sửa hơn.) */
    static NSRegularExpression *tokenRe = nil;
    if (!tokenRe) {
        tokenRe = [NSRegularExpression regularExpressionWithPattern:@"^[0-9a-fA-F]{32}$"
                                                            options:0 error:nil];
    }
    NSString *tok = [kPackageToken stringByTrimmingCharactersInSet:
                     [NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if ([tok isEqualToString:@"YOU_TOKEN_PACKAGE"]
        || tok.length != 32
        || [tokenRe numberOfMatchesInString:tok options:0 range:NSMakeRange(0, tok.length)] == 0) {
        [self gate_state_error:@"Chưa cấu hình kPackageToken trong HeaderAPI.h.\n\nMở trang admin (khanhduyz.fun/auth/login.php) → Packages → copy \"Project Token\" (32 ký tự hex) → dán vào kPackageToken rồi build lại app.\n\nLưu ý: token là 32 ký tự hex, không có khoảng trắng hay xuống dòng."];
        return;
    }

    NSDictionary *body = [core buildHelloRequest];
    if (!body) {
        [self gate_state_error:@"Lỗi cấu hình license — không tạo được request (kiểm tra HeaderAPI.h)."];
        return;
    }

    [self postLicense:body action:@"hello" sentNonce:@"" completion:^(NSDictionary *json, NSError *error) {
        if (gen != g_kdy_hello_gen) return;   /* lượt hello mới hơn đang chạy */

        if (error) {
            /* Mạng lỗi: KHÔNG exit — retry backoff, gate giữ nguyên */
            [LicenseCore diag:@"[LICENSE] hello network: %@", error.localizedDescription];
            [self kdy_hello_fail:[NSString stringWithFormat:@"Không kết nối được server: %@", error.localizedDescription]
                        baseDelay:2.0];
            return;
        }

        LicenseLease *info = nil;
        NSString *msg = nil;
        LicenseVerifyResult r = [[LicenseCore sharedCore] verifyResponse:json
                                                                  action:@"hello"
                                                               sentNonce:@""
                                                        thenMinSequence:0
                                                       expectedLicenseFp:nil
                                                                    lease:&info
                                                                  message:&msg
                                                               forceExit:NULL];
        if (r == LicenseVerifyInvalid) {
            /* Chữ ký sai / protocol sai → KHÔNG unlock, thử lại sau */
            [LicenseCore diag:@"[LICENSE] hello verify INVALID"];
            NSString *hint = [LicenseCore sharedCore].lastVerifyFailHint;
            [self kdy_hello_fail:[NSString stringWithFormat:@"Không xác thực được phản hồi server: %@",
                                      (hint.length > 0 ? hint : @"lý do không rõ")]
                        baseDelay:5.0];
            return;
        }
        if (r == LicenseVerifyRejected) {
            NSString *m = [self localizedServerMessage:msg ?: @"Lỗi hệ thống."];
            if (info && info.forceExit) {
                [self forceExitApp:m];
            } else {
                [self kdy_hello_fail:m baseDelay:10.0];
            }
            return;
        }

        /* hello OK — lưu challenge + contact */
        g_kdy_hello_fails = 0;   /* kết nối OK — reset bộ đếm */
        g_kdy_nonce_s = [info.nonceS copy];
        g_kdy_nonce_s_ts = (int64_t)([[NSDate date] timeIntervalSince1970] * 1000.0);
        if (info.contact.length > 0) self.contactLink = info.contact;
        self.isMaintenance = info.maintenance;
        [LicenseCore diag:@"[LICENSE] hello OK (maintenance=%d)", (int)info.maintenance];

        if (info.maintenance) {
            [[LicenseCore sharedCore] transitionTo:LicenseStateLocked];
            [self gate_state_maintenance];
            return;
        }

        /* Đã có key trong Keychain → auto-login; không → màn nhập key */
        NSString *stored = [[LicenseCore sharedCore] storedLicenseKey];
        if (stored.length > 0) {
            [self checkKey:stored isAuto:YES];
        } else {
            [[LicenseCore sharedCore] transitionTo:LicenseStateKeyPending];
            [self gate_state_input];
        }
    }];
}

- (void)kdy_hello_retry:(double)delay {
    int gen = g_kdy_hello_gen;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        if (gen != g_kdy_hello_gen) return;
        [self kdy_hello];
    });
}

/* Hello thất bại — đếm số lần, hiện lý do CỤ THỂ, backoff, sau 4 lần
 * liên tiếp thì dừng tự thử lại và hiện màn lỗi có nút THỬ LẠI.
 * (Trước đây: lỗi verify retry mãi mãi KHÔNG hiện gì — user chỉ thấy
 *  spinner xoay vô hạn mà không biết lý do.) */
- (void)kdy_hello_fail:(NSString *)reason baseDelay:(double)baseDelay {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self kdy_hello_fail:reason baseDelay:baseDelay]; });
        return;
    }
    g_kdy_hello_fails++;
    g_kdy_error_reason = [reason copy];

    if (g_kdy_hello_fails >= 4) {
        /* Đủ 4 lần liên tiếp — dừng vòng lặp âm thầm, đưa ra màn lỗi */
        [LicenseCore diag:@"[LICENSE] hello thất bại %ld lần — hiện màn lỗi", (long)g_kdy_hello_fails];
        [self gate_state_error:reason];
        return;
    }

    NSString *shortReason = (reason.length > 90) ? [NSString stringWithFormat:@"%@…", [reason substringToIndex:90]] : reason;
    NSString *status = [NSString stringWithFormat:@"%@\nthử lại lần %ld…", shortReason, (long)(g_kdy_hello_fails + 1)];
    [self gate_set_status:status color:kdy_gc(0x8E8E93, 1.0) shake:NO];

    /* Backoff: 2s → 3.2s → 5.1s → 8.2s (tối đa 10s) */
    double delay = MIN(baseDelay * pow(1.6, (double)(g_kdy_hello_fails - 1)), 10.0);
    [self kdy_hello_retry:delay];
}

/* Nút THỬ LẠI trên màn lỗi — reset bộ đếm, hello lại từ đầu */
- (void)kdy_retry_from_error {
    g_kdy_hello_fails = 0;
    g_kdy_error_reason = nil;
    [self gate_state_loading:@"Đang kết nối server..."];
    [self kdy_hello];
}

/* Reassert tick (lành tính — thay watchdog cũ): mỗi 45s kiểm tra gate
 * còn chiếm cửa sổ khi CHƯA authorized. Không giết app, không request
 * thêm — chỉ kick lại flow khi phát hiện gate bị bỏ đi. */
- (void)kdy_reassert_tick {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(45.0 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        [self kdy_reassert_gate];
        [self kdy_reassert_tick];
    });
}

#pragma mark - check key (V2 auth)

- (void)checkKey:(NSString *)key isAuto:(BOOL)isAuto {
    (void)isAuto;

    /* Validate nhanh client-side (tiết kiệm request — server vẫn validate lại) */
    NSString *k = [[key ?: @"" stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    if (k.length == 0) {
        [self gate_set_status:@"Vui lòng nhập key" color:kdy_gc(0xD5313B, 1.0) shake:YES];
        return;
    }
    if (k.length != 19 || [k characterAtIndex:4] != '-' || [k characterAtIndex:9] != '-' || [k characterAtIndex:14] != '-') {
        [self gate_set_status:@"Key không đúng định dạng (XXXX-XXXX-XXXX-XXXX)"
                        color:kdy_gc(0xD5313B, 1.0) shake:YES];
        return;
    }

    [self gate_state_loading:@"Đang kiểm tra key..."];

    /* Challenge hết hạn / chưa có → hello lại rồi auth tiếp */
    if (g_kdy_nonce_s.length == 0
        || ([[NSDate date] timeIntervalSince1970] * 1000.0 - g_kdy_nonce_s_ts) > 300000.0) {
        g_kdy_hello_gen++;
        [self postLicense:[[LicenseCore sharedCore] buildHelloRequest] action:@"hello" sentNonce:@""
            completion:^(NSDictionary *json, NSError *error) {
            if (error || !json) {
                [self kdy_hello_fail:[NSString stringWithFormat:@"Không kết nối được server: %@",
                                          (error.localizedDescription.length > 0 ? error.localizedDescription : @"lý do không rõ")]
                            baseDelay:3.0];
                return;
            }
            LicenseLease *info = nil;
            NSString *msg = nil;
            LicenseVerifyResult r = [[LicenseCore sharedCore] verifyResponse:json action:@"hello"
                                                                      sentNonce:@"" thenMinSequence:0
                                                             expectedLicenseFp:nil lease:&info message:&msg forceExit:NULL];
            if (r == LicenseVerifyGranted && info.nonceS.length == 32) {
                g_kdy_hello_fails = 0;   /* hello OK — reset bộ đếm */
                g_kdy_nonce_s = [info.nonceS copy];
                g_kdy_nonce_s_ts = (int64_t)([[NSDate date] timeIntervalSince1970] * 1000.0);
                if (info.contact.length > 0) self.contactLink = info.contact;
                if (info.maintenance) {
                    [self gate_state_maintenance];
                    return;
                }
                [self kdy_execute_auth:k isAuto:isAuto];
            } else if (r == LicenseVerifyRejected && info && info.forceExit) {
                [self forceExitApp:[self localizedServerMessage:msg ?: @"Lỗi hệ thống."]];
            } else {
                /* Invalid / Rejected không force-exit — hiện lý do cụ thể */
                NSString *hint = [LicenseCore sharedCore].lastVerifyFailHint;
                NSString *why = (r == LicenseVerifyInvalid && hint.length > 0)
                    ? [NSString stringWithFormat:@"Không xác thực được phản hồi server: %@", hint]
                    : (msg.length > 0 ? [self localizedServerMessage:msg] : @"Server chưa sẵn sàng.");
                [self kdy_hello_fail:why baseDelay:5.0];
            }
        }];
        return;
    }

    [self kdy_execute_auth:k isAuto:isAuto];
}

- (void)kdy_execute_auth:(NSString *)key isAuto:(BOOL)isAuto {
    if (g_kdy_in_auth) return;   /* chống double-tap LOGIN / double-auto */
    g_kdy_in_auth = YES;

    LicenseCore *core = [LicenseCore sharedCore];
    /* FIX BUG đá về màn nhập key: boot auto-login gọi checkKey khi state vẫn
     * NET_INIT → NET_INIT→AUTHENTICATING đã được thêm vào bảng transition
     * (DuyServer.mm). Lớp dự phòng: nếu vẫn bị reject (state lạ) thì đi vòng
     * qua KEY_PENDING — không để auth chạy với state sai rồi mất nhánh về AUTHORIZED. */
    if (![core transitionTo:LicenseStateAuthenticating]) {
        [core transitionTo:LicenseStateKeyPending];
        [core transitionTo:LicenseStateAuthenticating];
    }

    NSDictionary *body = [core buildAuthRequestForKey:key nonceS:g_kdy_nonce_s];
    if (!body) {
        g_kdy_in_auth = NO;
        [core transitionTo:LicenseStateKeyPending];
        /* Trước đây chỉ set_status trên màn loading → mất tích, spinner xoay
         * mãi. Giờ quay về màn nhập key để user THẤY lỗi và thử lại được. */
        [self gate_state_input];
        [self gate_set_status:@"Không tạo được chữ ký thiết bị (keypair lỗi) — bấm LOGIN để thử lại."
                        color:kdy_gc(0xD5313B, 1.0) shake:YES];
        return;
    }

    [self postLicense:body action:@"auth" sentNonce:body[@"nonce_c"]
        completion:^(NSDictionary *json, NSError *error) {
        g_kdy_in_auth = NO;

        if (error) {
            /* Lỗi mạng lúc auth: KHÔNG thoát, KHÔNG xóa key — báo + về input */
            [LicenseCore diag:@"[LICENSE] auth network: %@", error.localizedDescription];
            [core transitionTo:LicenseStateKeyPending];
            if (isAuto) {
                [self gate_state_input];
                [self gate_set_status:@"Không thể kết nối server. Vui lòng thử lại."
                                color:kdy_gc(0xD5313B, 1.0) shake:NO];
            } else {
                [self showAlert:@"Lỗi kết nối" message:error.localizedDescription retry:YES];
            }
            return;
        }

        LicenseLease *lease = nil;
        NSString *msg = nil;
        BOOL forceExit = NO;
        LicenseVerifyResult r = [core verifyResponse:json action:@"auth"
                                          sentNonce:(NSString *)body[@"nonce_c"]
                                   thenMinSequence:0
                                  expectedLicenseFp:nil
                                               lease:&lease
                                             message:&msg
                                          forceExit:&forceExit];

        if (r == LicenseVerifyGranted) {
            /* 11 bước verify pass — AUTHENTICATING → AUTHORIZED.
             * FIX BUG đá về màn nhập key: nếu transition bị reject (state
             * kẹt NET_INIT — boot auto-login không đi qua KEY_PENDING) thì
             * ensureAuthorized hồi phục qua chuỗi trung gian. Không có lớp
             * này: gate_dismiss chặn (state != AUTHORIZED) → mỗi lần "kích
             * hoạt thành công" vẫn bị đá về màn nhập key. */
            [core acceptLease:lease];
            [core ensureAuthorized];
            g_kdy_net_miss = 0;
            g_kdy_verify_fail = 0;
            g_kdy_nonce_s = nil;   /* challenge đã dùng — lần sau hello mới */

            /* Key hợp lệ → lưu Keychain (không còn NSUserDefaults) */
            [core storeLicenseKey:key];

            NSString *info = (lease.expiry.length > 0)
                ? [NSString stringWithFormat:@"Hạn dùng: %@ (%ld ngày)", lease.expiry, (long)lease.daysLeft]
                : @"Key hợp lệ";
            [self gate_state_success:info];
            [self kdy_beat_start];
            /* Task 18 — KHÔNG tự fetch offset sau auth: offset chỉ được cấp
             * khi user bấm "Activate ESP" (khi đó mới hỏi server key TƯƠI). */
            return;
        }

        if (r == LicenseVerifyRejected) {
            g_kdy_nonce_s = nil;   /* challenge single-use — refresh cho lần thử sau */

            /* Challenge expired → TỰ hello lại + auth lại (1 lần / 10s).
             * Đây là tình huống LÀNH TÍNH: nonce_s đã bị server consume bởi
             * một lần thử trước đó MẤT phản hồi trên mạng (server xử lý xong
             * nhưng client không nhận được), hoặc hello/auth vượt TTL 10
             * phút. Thay vì đẩy lỗi về user, client chủ động lấy challenge
             * mới (hello tươi) rồi auth lại ngay — user không cần bấm gì.
             *
             * Chống vòng lặp: gate 10 giây — nếu server vẫn báo expired ngay
             * cả với nonce_s mới-toanh thì lỗi nằm ở server, lần này hiện
             * thông báo để user biết thay vì xoay vô hạn. */
            int64_t nowMs = (int64_t)([[NSDate date] timeIntervalSince1970] * 1000.0);
            if ([msg isEqualToString:@"Challenge expired"]
                && (nowMs - g_kdy_last_challenge_re) > 10000) {
                g_kdy_last_challenge_re = nowMs;
                [LicenseCore diag:@"[LICENSE] challenge expired — tự hello lại + auth lại"];
                [self checkKey:key isAuto:isAuto];
                return;
            }

            [self kdy_handle_auth_reject:(msg ?: @"Key không hợp lệ.") key:key forceExit:forceExit];
            return;
        }

        /* Invalid: chữ ký/protocol sai — KHÔNG BAO GIỜ unlock theo phản hồi này */
        [LicenseCore diag:@"[LICENSE] auth verify INVALID — phản hồi bị từ chối (fail-closed)"];
        g_kdy_nonce_s = nil;
        [core transitionTo:LicenseStateKeyPending];
        [self gate_state_input];
        NSString *authHint = [LicenseCore sharedCore].lastVerifyFailHint;
        NSString *authWhy = (authHint.length > 0)
            ? [NSString stringWithFormat:@"Không xác minh được phản hồi server: %@", authHint]
            : @"Không thể xác minh phản hồi server.";
        [self gate_set_status:authWhy
                        color:kdy_gc(0xD5313B, 1.0) shake:NO];
    }];
}

- (void)kdy_handle_auth_reject:(NSString *)message key:(NSString *)key forceExit:(BOOL)forceExit {
    LicenseCore *core = [LicenseCore sharedCore];

    if (forceExit) {
        [core transitionTo:LicenseStateLocked];
        kdy_offsets_reset();   /* Task 17 — khóa là offset chết ngay */
        [self forceExitApp:[self localizedServerMessage:message]];
        return;
    }

    /* Maintenance → màn bảo trì (khớp hành vi V1) */
    if ([message isEqualToString:@"System Maintenance"]) {
        [core transitionTo:LicenseStateLocked];
        [self gate_state_maintenance];
        return;
    }

    [core transitionTo:LicenseStateKeyPending];
    [self handleInvalidKey:key message:[self localizedServerMessage:message]];
}

- (void)handleInvalidKey:(NSString *)key message:(NSString *)msg {
    /* Chỉ xóa key lưu khi từ chối là DỨT KHOÁT về key (invalid/expired/
     * revoked/suspended/max device) — lỗi tạm thời giữ key để retry. */
    NSArray<NSString *> *definitive = @[
        @"Key invalid for this package", @"Key expired", @"Key revoked",
        @"Key suspended", @"Max devices reached", @"Device mismatch",
        @"Device verification failed", @"Invalid params",
    ];
    NSString *raw = [self deLocalizeServerMessage:msg];
    BOOL isDefinitive = NO;
    for (NSString *d in definitive) {
        if ([raw hasPrefix:d]) { isDefinitive = YES; break; }
    }
    if (isDefinitive) {
        [[LicenseCore sharedCore] clearStoredLicenseKey];
        kdy_offsets_reset();   /* Task 17 — key sai thì ESP/Aim phải chết */
    }

    dispatch_async(dispatch_get_main_queue(), ^{
        [self gate_state_input];
        UIColor *errColor = [UIColor colorWithRed:1.0 green:0.35 blue:0.35 alpha:1.0];
        NSString *errMsg = (msg.length > 0) ? msg : @"Key không hợp lệ";
        [self gate_set_status:errMsg color:errColor shake:YES];
    });
}

#pragma mark - Fetch offsets / key check (Task 17 + 18 — server-authoritative)

/* Offset game CHỈ tồn tại trên server. Task 18: KHÔNG tự đổ offset sau
 * auth/renew — duy nhất lượt CHECK KHI BẤM "Activate ESP" (force) hỏi
 * server key TƯƠI (pop3 + session + key status trong DB). Phản hồi phải
 * verify chữ ký ECDSA + lease + device_binding như renew; offsets nằm
 * trong chuỗi ĐÃ KÝ — chỉ tin lease.offsetsJSON. Key sai / chưa nhập /
 * crack → không bao giờ có offset → ESP & Aim không hoạt động.
 * Dữ liệu connect lẫn offset DÙNG CÙNG một chuẩn hiện nay: HTTPS +
 * chữ ký ECDSA P-256 + device_binding trong payload. */

/* Passive — chỉ retry sau lỗi mạng của một lượt check trước đó. */
- (void)kdy_fetch_offsets {
    if (kdy_offsets_ready()) return;
    [self kdy_fetch_offsets_run:NO];
}

/* Task 18 — bấm "Activate ESP": hỏi server TƯƠI mỗi lần, kể cả khi đã
 * có offset (bằng chứng key vẫn đúng NGAY LÚC bấm — revoke ngay trước
 * đó thì lượt này bị server từ chối và ESP không chạy). */
- (void)kdy_fetch_offsets_check {
    [self kdy_fetch_offsets_run:YES];
}

- (void)kdy_fetch_offsets_run:(BOOL)force {
    if (!force && kdy_offsets_ready()) return;  /* passive: đã có thì thôi */

    LicenseCore *core = [LicenseCore sharedCore];
    /* Đang renew hoặc đang có request bay → đợi 2s rồi thử lại (tránh 2
     * request dùng cùng 1 sequence — server bump trước → request sau bị
     * 'Sequence mismatch' → phải auth lại gây nhiễu). Vòng chờ tự hủy khi
     * có fetch mới (gen đổi) hoặc offset đã có. */
    if (core.state == LicenseStateRenewing || g_kdy_in_offsets_fetch) {
        int wgen = g_kdy_offsets_gen;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            if (wgen != g_kdy_offsets_gen) return;
            if (kdy_offsets_ready()) return;
            [self kdy_fetch_offsets_run:force];
        });
        return;
    }

    LicenseLease *cur = core.currentLease;
    if (!cur || ![core sessionUsable]) {
        [LicenseCore diag:@"[OFFSET] không có lease hợp lệ — không fetch"];
        if (force) {
            [[NSNotificationCenter defaultCenter]
                postNotificationName:kdy_offsets_check_deny
                              object:nil
                            userInfo:@{@"reason": @"Phiên license chưa hợp lệ — hãy đăng nhập lại."}];
        }
        return;
    }

    NSDictionary *body = [core buildOffsetsRequest];
    if (!body) {
        [LicenseCore diag:@"[OFFSET] không tạo được request (keypair lỗi)"];
        if (force) {
            [[NSNotificationCenter defaultCenter]
                postNotificationName:kdy_offsets_check_deny
                              object:nil
                            userInfo:@{@"reason": @"Thiết bị chưa sẵn sàng (khóa ký lỗi) — bấm lại."}];
        }
        return;
    }

    g_kdy_in_offsets_fetch = YES;
    int gen = ++g_kdy_offsets_gen;

    [self postLicense:body action:@"offsets" sentNonce:body[@"nonce_c"]
        completion:^(NSDictionary *json, NSError *error) {
        g_kdy_in_offsets_fetch = NO;
        if (gen != g_kdy_offsets_gen) return;   /* fetch mới đã thay thế */

        if (error) {
            g_kdy_offsets_fails++;
            [LicenseCore diag:@"[OFFSET] network miss #%d", g_kdy_offsets_fails];
            [self kdy_offsets_retry_later:(g_kdy_offsets_fails >= 5) ? 120.0 : 20.0];
            return;
        }

        LicenseLease *lease = nil;
        NSString *msg = nil;
        LicenseVerifyResult r = [core verifyResponse:json action:@"offsets"
                                          sentNonce:(NSString *)body[@"nonce_c"]
                                   thenMinSequence:cur.sequence
                                  expectedLicenseFp:cur.licenseFp
                                               lease:&lease
                                             message:&msg
                                          forceExit:NULL];

        if (r == LicenseVerifyGranted) {
            /* Server đã bump sequence cho call này — PHẢI nhận lease mới
             * (kể cả khi payload offset trống) kẻo lệch sequence. */
            [core acceptLease:lease];
            [core ensureAuthorized];

            if (lease && lease.offsetsJSON.length > 2) {
                const char *offsUtf8 = lease.offsetsJSON.UTF8String;
                size_t offsLen = [lease.offsetsJSON lengthOfBytesUsingEncoding:NSUTF8StringEncoding];
                NSString *gv = (lease.gameVersion.length > 0) ? lease.gameVersion : @"";
                const char *gvUtf8 = gv.UTF8String ?: "";
                size_t gvLen = [gv lengthOfBytesUsingEncoding:NSUTF8StringEncoding];

                if (offsUtf8 && kdy_offsets_apply_json(offsUtf8, offsLen, gvUtf8, gvLen)) {
                    g_kdy_offsets_fails = 0;
                    [LicenseCore diag:@"[OFFSET] áp offset OK (version=%@)", gv];
                    /* Task 18 — báo ESPInstaller đang chờ: KEY ĐÚNG,
                     * server đã cấp offset (kèm game version). */
                    [[NSNotificationCenter defaultCenter]
                        postNotificationName:kdy_offsets_check_ok
                                      object:nil
                                    userInfo:@{@"version": gv}];
                    return;
                }
                /* Payload thiếu slot / layout lệch → fail-closed: reset,
                 * ESP/Aim chết, retry chậm (server đang cấu hình sai). */
                kdy_offsets_reset();
                [LicenseCore diag:@"[OFFSET] payload bị từ chối (thiếu slot / layout lệch)"];
                [self kdy_offsets_retry_later:60.0];
                return;
            }

            /* Granted nhưng server chưa cấu hình offsets — mềm: retry. */
            [LicenseCore diag:@"[OFFSET] server chưa trả offsets"];
            [self kdy_offsets_retry_later:60.0];
            return;
        }

        if (r == LicenseVerifyRejected) {
            /* kdy_handle_lease_reject post kdy_offsets_check_deny cho
             * ESPInstaller (Task 18) rồi tự xử lý gate/state như trước. */
            [self kdy_handle_lease_reject:msg ?: @"Session expired"];
            return;
        }

        /* Invalid — chữ ký sai / MITM: KHÔNG áp offset (fail-closed). */
        g_kdy_offsets_fails++;
        [LicenseCore diag:@"[OFFSET] verify INVALID #%d", g_kdy_offsets_fails];
        [self kdy_offsets_retry_later:30.0];
    }];
}

- (void)kdy_offsets_retry_later:(double)sec {
    int gen = g_kdy_offsets_gen;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(sec * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        if (gen != g_kdy_offsets_gen) return;    /* đã có fetch mới */
        if (kdy_offsets_ready()) return;
        LicenseState st = [LicenseCore sharedCore].state;
        if (st != LicenseStateAuthorized && st != LicenseStateGrace) {
            return;   /* đang renew / chưa auth / đã khóa — Task 18: offset
                       * chỉ đến qua lượt check khi bấm Activate ESP */
        }
        [self kdy_fetch_offsets];
    });
}

/* Từ chối khi fetch offset — giống ngữ nghĩa renew-rejected nhưng gọn
 * (không đụng nhánh renew đã verify Task 15). Mọi nhánh đều RESET offset. */
- (void)kdy_handle_lease_reject:(NSString *)m {
    LicenseCore *core = [LicenseCore sharedCore];
    kdy_offsets_reset();

    /* Task 18 — báo ESPInstaller đang chờ kết quả check: server TỪ CHỐI
     * cấp offset (key sai / revoked / expired / maintenance…). Lý do đã
     * dịch tiếng Việt để hiện ngay trên màn Activate. */
    [[NSNotificationCenter defaultCenter] postNotificationName:kdy_offsets_check_deny
                                                        object:nil
                                                      userInfo:@{@"reason": [self localizedServerMessage:m]}];

    if ([m isEqualToString:@"System Maintenance"]) {
        [core transitionTo:LicenseStateLocked];
        [self gate_state_maintenance];
        return;
    }
    if ([m isEqualToString:@"Session expired"] || [m isEqualToString:@"Sequence mismatch"]) {
        [self kdy_restart_auth];
        return;
    }
    if ([m isEqualToString:@"Key revoked"]) {
        [core clearLease];
        [core clearStoredLicenseKey];
        [core transitionTo:LicenseStateRevoked];
        [self gate_state_input];
        [self gate_set_status:[self localizedServerMessage:m]
                        color:kdy_gc(0xD5313B, 1.0) shake:NO];
        return;
    }
    if ([m isEqualToString:@"Key expired"] || [m isEqualToString:@"Key suspended"]) {
        [core clearLease];
        [core clearStoredLicenseKey];
        [core transitionTo:LicenseStateExpired];
        [self gate_state_input];
        [self gate_set_status:[self localizedServerMessage:m]
                        color:kdy_gc(0xD5313B, 1.0) shake:NO];
        return;
    }
    if ([m isEqualToString:@"Offsets unavailable"]) {
        /* Admin chưa bật offset (đang update game) — mềm, không lockdown. */
        g_kdy_offsets_fails++;
        [self kdy_offsets_retry_later:60.0];
        return;
    }
    [self kdy_lockdown:[self localizedServerMessage:m]];
}

#pragma mark - Renew loop (lease ngắn hạn + grace)

- (void)kdy_beat_start {
    [self kdy_beat_schedule:90.0];
}

- (void)kdy_beat_schedule:(double)sec {
    int gen = ++g_kdy_renew_gen;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(sec * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        if (gen == g_kdy_renew_gen) {
            [self kdy_beat_fire];
        }
    });
}

- (void)kdy_beat_fire {
    LicenseCore *core = [LicenseCore sharedCore];
    LicenseState st = core.state;
    if (st != LicenseStateAuthorized && st != LicenseStateRenewing && st != LicenseStateGrace) {
        return;   /* chưa auth / đã khóa — không renew */
    }

    int64_t now = (int64_t)([[NSDate date] timeIntervalSince1970] * 1000.0);
    if (now - g_kdy_last_beat_ms < 90000) {
        [self kdy_beat_schedule:95.0];   /* debounce 90s (giữ hành vi V1) */
        return;
    }
    g_kdy_last_beat_ms = now;

    if (![core sessionUsable]) {
        /* Grace đã cạn → khóa, yêu cầu auth lại */
        [self kdy_lockdown:@"Phiên đã hết hạn do mất kết nối lâu."];
        return;
    }

    [self kdy_renew_now];
}

- (void)kdy_renew_now {
    LicenseCore *core = [LicenseCore sharedCore];
    LicenseLease *cur = core.currentLease;
    if (!cur) {
        [self kdy_lockdown:@"Phiên không hợp lệ."];
        return;
    }

    [core transitionTo:LicenseStateRenewing];
    NSDictionary *body = [core buildRenewRequest];
    if (!body) {
        [core transitionTo:LicenseStateGrace];
        [self kdy_beat_schedule:60.0];
        return;
    }

    [self postLicense:body action:@"renew" sentNonce:body[@"nonce_c"]
        completion:^(NSDictionary *json, NSError *error) {
        if (error) {
            /* Mạng lỗi → GRACE (còn dùng tiếp trong grace do server ký),
             * retry backoff 15/30/60/120/300s — KHÔNG đếm để kill như cũ. */
            g_kdy_net_miss++;
            double delays[] = {15.0, 30.0, 60.0, 120.0, 300.0};
            double d = delays[MIN(g_kdy_net_miss - 1, 4)];
            [core transitionTo:LicenseStateGrace];
            [LicenseCore diag:@"[LICENSE] renew network miss #%d — retry %.0fs", g_kdy_net_miss, d];
            [self kdy_beat_schedule:d];
            return;
        }

        LicenseLease *lease = nil;
        NSString *msg = nil;
        LicenseVerifyResult r = [core verifyResponse:json action:@"renew"
                                          sentNonce:(NSString *)body[@"nonce_c"]
                                   thenMinSequence:cur.sequence
                                  expectedLicenseFp:cur.licenseFp
                                               lease:&lease
                                             message:&msg
                                          forceExit:NULL];

        if (r == LicenseVerifyGranted) {
            [core acceptLease:lease];
            [core ensureAuthorized];   /* FIX lockout: phòng state kẹt — renew OK phải về được AUTHORIZED */
            g_kdy_net_miss = 0;
            g_kdy_verify_fail = 0;
            if (lease.contact.length > 0) self.contactLink = lease.contact;
            /* Lịch renew = lease_ttl/2 + jitter (giữ ~12-18 req/h như V1) */
            double next = (double)lease.leaseTtl / 2.0 + (double)(arc4random_uniform(40));
            if (next < 60.0) next = 60.0;
            [self kdy_beat_schedule:next];
            /* Task 18 — renew KHÔNG tự fetch offset. Offset chỉ đến qua lượt
             * check khi bấm "Activate ESP"; ESP đang chạy thì đã có sẵn và
             * bị revoke bất kỳ lúc nào thì rosterTick gate sẽ giết (Task 17). */
            return;
        }

        if (r == LicenseVerifyRejected) {
            NSString *m = msg ?: @"Key không hợp lệ.";
            [LicenseCore diag:@"[LICENSE] renew rejected: %@", m];

            if ([m isEqualToString:@"System Maintenance"]) {
                [core transitionTo:LicenseStateLocked];
                [self gate_state_maintenance];
                return;
            }
            if ([m isEqualToString:@"Session expired"] || [m isEqualToString:@"Sequence mismatch"]) {
                /* Hết phiên → auth lại bằng key đã lưu (UX mượt, vẫn server-authority) */
                [self kdy_restart_auth];
                return;
            }
            if ([m isEqualToString:@"Key revoked"]) {
                [core clearLease];
                kdy_offsets_reset();   /* Task 17 */
                [core clearStoredLicenseKey];
                [core transitionTo:LicenseStateRevoked];
                [self gate_state_input];
                [self gate_set_status:[self localizedServerMessage:m]
                                color:kdy_gc(0xD5313B, 1.0) shake:NO];
                return;
            }
            if ([m isEqualToString:@"Key expired"] || [m isEqualToString:@"Key suspended"]) {
                [core clearLease];
                kdy_offsets_reset();   /* Task 17 */
                [core clearStoredLicenseKey];
                [core transitionTo:LicenseStateExpired];
                [self gate_state_input];
                [self gate_set_status:[self localizedServerMessage:m]
                                color:kdy_gc(0xD5313B, 1.0) shake:NO];
                return;
            }
            /* Từ chối khác (Device mismatch / PoP fail → server đã tự hủy
             * session coi như clone) → khóa toàn bộ */
            [self kdy_lockdown:[self localizedServerMessage:m]];
            return;
        }

        /* Invalid — chữ ký sai giữa phiên: HOẶC server đang rotate key,
         * HOẶC đang bị MITM giả phản hồi. Fail-closed: grace + retry,
         * 3 lần sai liên tiếp → lockdown (không kill app). */
        g_kdy_verify_fail++;
        [core transitionTo:LicenseStateGrace];
        [LicenseCore diag:@"[LICENSE] renew verify INVALID #%d", g_kdy_verify_fail];
        if (g_kdy_verify_fail >= 3) {
            [self kdy_lockdown:@"Không thể xác minh server — phiên bị khóa an toàn."];
        } else {
            [self kdy_beat_schedule:30.0];
        }
    }];
}

/* Khóa chức năng: hiện lại gate, xóa lease, auth lại nếu còn key */
- (void)kdy_lockdown:(NSString *)reason {
    LicenseCore *core = [LicenseCore sharedCore];
    kdy_offsets_reset();   /* Task 17 — khóa phiên là offset chết ngay */
    [core clearLease];
    [core transitionTo:LicenseStateLocked];

    [self gate_show];
    [self gate_state_loading:@"Đang xác thực lại..."];
    [self gate_set_status:reason color:kdy_gc(0xD5313B, 1.0) shake:NO];

    [self kdy_restart_auth];
}

- (void)kdy_restart_auth {
    LicenseCore *core = [LicenseCore sharedCore];
    [core transitionTo:LicenseStateNetInit];
    g_kdy_hello_gen++;

    [self postLicense:[core buildHelloRequest] action:@"hello" sentNonce:@""
        completion:^(NSDictionary *json, NSError *error) {
        if (error) {
            [self kdy_hello_fail:[NSString stringWithFormat:@"Không kết nối được server: %@",
                                      (error.localizedDescription.length > 0 ? error.localizedDescription : @"lý do không rõ")]
                        baseDelay:5.0];
            return;
        }
        LicenseLease *info = nil;
        NSString *msg = nil;
        LicenseVerifyResult r = [core verifyResponse:json action:@"hello" sentNonce:@""
                                          thenMinSequence:0 expectedLicenseFp:nil
                                          lease:&info message:&msg forceExit:NULL];
        if (r != LicenseVerifyGranted) {
            if (r == LicenseVerifyRejected && info && info.forceExit) {
                [self forceExitApp:[self localizedServerMessage:msg ?: @"Lỗi hệ thống."]];
                return;
            }
            NSString *hint = [LicenseCore sharedCore].lastVerifyFailHint;
            NSString *why = (r == LicenseVerifyInvalid && hint.length > 0)
                ? [NSString stringWithFormat:@"Không xác thực được phản hồi server: %@", hint]
                : (msg.length > 0 ? [self localizedServerMessage:msg] : @"Server chưa sẵn sàng.");
            [self kdy_hello_fail:why baseDelay:10.0];
            return;
        }
        g_kdy_hello_fails = 0;   /* hello OK — reset bộ đếm */
        g_kdy_nonce_s = [info.nonceS copy];
        g_kdy_nonce_s_ts = (int64_t)([[NSDate date] timeIntervalSince1970] * 1000.0);
        if (info.contact.length > 0) self.contactLink = info.contact;
        if (info.maintenance) {
            [core transitionTo:LicenseStateLocked];
            [self gate_state_maintenance];
            return;
        }
        NSString *stored = [core storedLicenseKey];
        if (stored.length > 0) {
            [self checkKey:stored isAuto:YES];
        } else {
            [core transitionTo:LicenseStateKeyPending];
            [self gate_state_input];
        }
    }];
}

/* Nghe app trở lại foreground → renew ngay (đã debounce 90s bên trong) */
- (void)kdy_resume_observe {
    if (g_kdy_observer_added) return;
    g_kdy_observer_added = YES;
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(kdy_resume_tick)
                                                 name:UIApplicationDidBecomeActiveNotification
                                               object:nil];
}

- (void)kdy_resume_tick {
    LicenseCore *core = [LicenseCore sharedCore];
    LicenseState st = core.state;
    if (st == LicenseStateAuthorized || st == LicenseStateRenewing || st == LicenseStateGrace) {
        [self kdy_beat_fire];
        return;
    }
    /* Foreground khi chưa auth (gate đã hiện nhưng flow chết) → kick lại */
    [self kdy_reassert_gate];
}

/* Kiểm tra gate còn chiếm cửa sổ khi CHƯA authorized — chạy trong beat
 * timer. Thay watchdog cũ bằng reassert lành tính (không kill app). */
- (void)kdy_reassert_gate {
    LicenseCore *core = [LicenseCore sharedCore];
    LicenseState st = core.state;
    BOOL gated = (st == LicenseStateAuthorized || st == LicenseStateRenewing
                  || st == LicenseStateGrace);
    if (gated) return;

    BOOL gateVisible = NO;
    if (g_kdy_app_window && g_kdy_vc && g_kdy_app_window.rootViewController == g_kdy_vc) {
        gateVisible = YES;
    } else if (g_kdy_tmp_window && !g_kdy_tmp_window.hidden) {
        gateVisible = YES;
    }
    if (!gateVisible) {
        [LicenseCore diag:@"[LICENSE] gate không còn hiện — reassert"];
        [self gate_show];
        [self gate_state_loading:@"Đang xác thực..."];
        [self kdy_restart_auth];
    }
}

#pragma mark - Localization

/* Dịch thông điệp THẨN TRỊ server sang tiếng Việt cho UIKey.
 * Giữ nguyên mọi thông điệp lạ không nằm trong bảng. */
- (NSString *)localizedServerMessage:(NSString *)raw {
    if (![raw isKindOfClass:[NSString class]] || raw.length == 0) {
        return @"Lỗi không xác định.";
    }
    NSDictionary *map = @{
        @"Key invalid for this package" : @"Key không hợp lệ cho package này.",
        @"Key expired"                   : @"Key đã hết hạn sử dụng.",
        @"Key revoked"                   : @"Key đã bị thu hồi vĩnh viễn.",
        @"Key suspended"                 : @"Key đã bị tạm dừng.",
        @"Max devices reached"           : @"Key đã dùng hết số thiết bị cho phép.",
        @"Device mismatch"               : @"Thiết bị không khớp — khóa thiết bị đã đổi.\nVào admin → Keys → Reset Devices rồi mở app thử lại.",
        @"Device verification failed"    : @"Xác minh thiết bị thất bại.",
        @"Request expired"               : @"Hết thời gian yêu cầu — kiểm tra giờ thiết bị (Cài đặt → Ngày & Giờ → Tự động).",
        @"Replay detected"               : @"Phát hiện yêu cầu bị phát lại — từ chối.",
        @"Challenge expired"             : @"Phiên xác minh hết hạn, vui lòng thử lại.",
        @"Session expired"               : @"Phiên đăng nhập hết hạn — xác thực lại.",
        @"Sequence mismatch"             : @"Phiên không đồng bộ — xác thực lại.",
        @"Missing params"                : @"Thiếu thông tin key hoặc UUID.",
        @"Invalid params"                : @"Dữ liệu gửi lên không hợp lệ.",
        @"Invalid Package Token"         : @"Package Token không tồn tại — kiểm tra kPackageToken trong HeaderAPI.h.",
        @"Missing Package Token"         : @"Thiếu Package Token — kiểm tra kPackageToken trong HeaderAPI.h.",
        @"Database unavailable"          : @"Server lỗi cơ sở dữ liệu, vui lòng thử lại sau.",
        @"Too many requests"             : @"Quá nhiều yêu cầu — đợi 1–2 phút rồi bấm LOGIN lại.",
        @"System Maintenance"            : @"Hệ thống đang bảo trì, vui lòng quay lại sau.",
        @"Server error"                  : @"Server gặp lỗi không xác định.",
        @"Unknown action"                : @"Yêu cầu không hợp lệ.",
        @"Database error"                : @"Server lỗi cơ sở dữ liệu, vui lòng thử lại sau.",
        @"Offsets unavailable"            : @"Offset chưa sẵn sàng trên server — ESP/Aim tạm dừng.",
    };
    NSString *mapped = map[raw];
    if (mapped.length > 0) {
        return mapped;
    }
    /* Server có thể trả kèm mã SQLSTATE để chẩn đoán, ví dụ
     * 'Database error (42S22)' — match theo prefix để vẫn dịch được. */
    if ([raw hasPrefix:@"Database error"]) {
        return @"Server lỗi cơ sở dữ liệu, vui lòng thử lại sau.";
    }
    return raw;
}

/* Ngược lại: từ message đã dịch tìm lại chuỗi gốc để so khớp logic */
- (NSString *)deLocalizeServerMessage:(NSString *)msg {
    if (![msg isKindOfClass:[NSString class]]) return @"";
    NSDictionary *map = @{
        @"Key không hợp lệ cho package này." : @"Key invalid for this package",
        @"Key đã hết hạn sử dụng."           : @"Key expired",
        @"Key đã bị thu hồi vĩnh viễn."      : @"Key revoked",
        @"Key đã bị tạm dừng."               : @"Key suspended",
        @"Key đã dùng hết số thiết bị cho phép." : @"Max devices reached",
        @"Thiết bị không khớp — khóa thiết bị đã đổi.\nVào admin → Keys → Reset Devices rồi mở app thử lại." : @"Device mismatch",
        @"Xác minh thiết bị thất bại."       : @"Device verification failed",
        @"Dữ liệu gửi lên không hợp lệ."     : @"Invalid params",
    };
    NSString *mapped = map[msg];
    return (mapped.length > 0) ? mapped : msg;
}

/* Boundary hook — gọi từ ESPInstallerViewController (điểm vào tính năng
 * nhạy cảm). Hiện lại gate + tự auth lại nếu còn key. */
extern "C" void LicenseReassertGate(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        khanhduy *inst = [khanhduy sharedInstance];
        [inst gate_show];
        [inst gate_state_loading:@"Đang xác thực..."];
        [inst kdy_restart_auth];
    });
}

/* Task 17 — boundary ESP/Aim gọi khi cần offset mà chưa có
 * (activation bị chặn vì chưa fetch xong). Kick fetch ngay. */
extern "C" void LicenseFetchOffsets(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        [[khanhduy sharedInstance] kdy_fetch_offsets];
    });
}

/* Task 18 — ESPInstaller gọi NGAY KHI BẤM "Activate ESP": kiểm tra key
 * với server TƯƠI (pop3 + session + key status trong DB); ĐÚNG key thì
 * offset mới được đổ xuống — nằm trong lease ĐÃ KÝ như connect data.
 * Kết quả qua notification kdy_offsets_check_ok / kdy_offsets_check_deny
 * (main thread). Key sai / chưa nhập / crack → không bao giờ có offset
 * → ESP & Aim không chạy. */
extern "C" void LicenseActivateESPCheck(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        [[khanhduy sharedInstance] kdy_fetch_offsets_check];
    });
}

// ======================================================================
// GATE UI — giữ nguyên trải nghiệm UIKey của V1 (màn đen tích hợp root,
// loading/input/success/maintenance, rung khi sai, link liên hệ).
// Thay duy nhất: điều kiện mở khóa = AUTHORIZED + lease còn hạn (V2),
// không còn flag g_kdy_verified hay token đa kho.
// (Gate category đã gộp vào @implementation chính — hết warning
//  incomplete-implementation và category-implementation.)
// ======================================================================

- (UIViewController *)gate_presenter {
    if (g_kdy_vc) return g_kdy_vc;
    return [self getTopViewController];
}

- (void)gate_show {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self gate_show]; });
        return;
    }
    if ([self gate_attach]) {
        [self gate_state_loading:@"Đang kết nối server..."];
    }
}

/* GẮN MÀN KEY VÀO CỬA SỔ CHÍNH CỦA APP — một khối, không nổi (như V1). */
- (BOOL)gate_attach {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self gate_attach]; });
        return NO;
    }

    /* đã tích hợp vào cửa sổ chính rồi */
    if (g_kdy_app_window && g_kdy_vc && g_kdy_app_window.rootViewController == g_kdy_vc) {
        return YES;
    }

    UIWindowScene *scene = nil;
    if (@available(iOS 13.0, *)) {
        UIApplication *sharedApp = [UIApplication sharedApplication];
        for (UIScene *s in sharedApp.connectedScenes) {
            if ([s isKindOfClass:[UIWindowScene class]]) {
                scene = (UIWindowScene *)s;
                if (s.activationState == UISceneActivationStateForegroundActive) break;
            }
        }
        if (!scene) {
            int gen = ++g_kdy_retry_gen;
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.15 * NSEC_PER_SEC)),
                           dispatch_get_main_queue(), ^{
                if (g_kdy_app_window || g_kdy_tmp_window) return;
                if (gen != g_kdy_retry_gen) return;
                [self gate_show];
            });
            return NO;
        }
    }

    /* tìm cửa sổ CHÍNH của app trong scene (bỏ qua cửa sổ tạm của gate) */
    UIWindow *appWin = nil;
    if (scene) {
        for (UIWindow *w in scene.windows) {
            if (w == g_kdy_tmp_window) continue;
            if (w.rootViewController) { appWin = w; break; }
            if (!appWin) appWin = w;
        }
    }

    if (appWin) {
        /* === CHUYỂN GIAO: gate trở thành root của cửa sổ chính === */
        if (!g_kdy_vc) {
            UIViewController *vc = [[UIViewController alloc] init];
            vc.view.backgroundColor = kdy_gc(0xF2F2F7, 1.0);
            if (@available(iOS 13.0, *)) {
                vc.overrideUserInterfaceStyle = UIUserInterfaceStyleLight;
            }
            g_kdy_vc = vc;
        }
        UIViewController *orig = appWin.rootViewController;
        if (orig && orig != g_kdy_vc) g_kdy_orig_root = orig;
        appWin.rootViewController = g_kdy_vc;
        g_kdy_app_window = appWin;
        [appWin makeKeyAndVisible];

        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.05 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            [self kdy_drop_tmp_window];
        });
        return YES;
    }

    /* cửa sổ chính chưa xuất hiện → phủ đen tạm, chờ chuyển giao */
    if (!g_kdy_tmp_window) {
        UIViewController *vc = [[UIViewController alloc] init];
        vc.view.backgroundColor = kdy_gc(0xF2F2F7, 1.0);
        if (@available(iOS 13.0, *)) {
            vc.overrideUserInterfaceStyle = UIUserInterfaceStyleLight;
        }
        g_kdy_vc = vc;
        if (scene) {
            g_kdy_tmp_window = [[UIWindow alloc] initWithWindowScene:scene];
        } else {
            g_kdy_tmp_window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
        }
        g_kdy_tmp_window.windowLevel = UIWindowLevelStatusBar + 100.0;
        g_kdy_tmp_window.backgroundColor = kdy_gc(0xF2F2F7, 1.0);
        g_kdy_tmp_window.rootViewController = vc;
        [g_kdy_tmp_window makeKeyAndVisible];
    }

    g_kdy_attach_tries++;
    if (g_kdy_attach_tries < 80) {
        int gen = ++g_kdy_retry_gen;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.15 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            if (g_kdy_app_window) return;
            if (gen != g_kdy_retry_gen) return;
            [self gate_attach];
        });
    }
    return YES;
}

- (void)kdy_drop_tmp_window {
    if (!g_kdy_tmp_window) return;
    UIWindow *w = g_kdy_tmp_window;
    g_kdy_tmp_window = nil;
    w.hidden = YES;
    [w removeFromSuperview];
}

- (void)gate_state_loading:(NSString *)msg {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self gate_state_loading:msg]; });
        return;
    }
    [self gate_attach];
    if (!g_kdy_vc) return;

    UIView *root = g_kdy_vc.view;
    for (UIView *v in [root subviews]) [v removeFromSuperview];
    for (UIGestureRecognizer *gr in [root.gestureRecognizers copy]) {
        [root removeGestureRecognizer:gr];
    }
    g_kdy_input = nil;
    g_kdy_group = nil;
    g_kdy_status = nil;

    CGRect b = root.bounds;
    if (CGRectIsEmpty(b)) b = [UIScreen mainScreen].bounds;

    [root addSubview:kdy_gate_background(b)];

    /* logo + thương hiệu phía trên */
    CGFloat logoSize = 72.0;
    UIView *logo = kdy_gate_logo(logoSize);
    logo.center = CGPointMake(b.size.width / 2.0, b.size.height * 0.30);
    logo.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin |
                            UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;
    [root addSubview:logo];

    UILabel *brand = [[UILabel alloc] initWithFrame:CGRectMake(0, b.size.height * 0.30 + logoSize / 2.0 + 24, b.size.width, 24)];
    brand.text = @"FreeFire Ds";
    brand.textColor = kdy_gc(0x1C1C1E, 1.0);
    brand.font = [UIFont systemFontOfSize:17 weight:UIFontWeightSemibold];
    brand.textAlignment = NSTextAlignmentCenter;
    brand.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;
    [root addSubview:brand];

    UIActivityIndicatorView *spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleLarge];
    CGSize spSize = spinner.frame.size;
    spinner.color = kdy_gc(0x8E8E93, 1.0);
    spinner.frame = CGRectMake((b.size.width - spSize.width) / 2.0,
                               b.size.height * 0.48,
                               spSize.width,
                               spSize.height);
    spinner.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin |
                               UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;
    [spinner startAnimating];
    [root addSubview:spinner];

    UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(0, spinner.frame.origin.y + spSize.height + 18, b.size.width, 22)];
    lbl.text = (msg.length > 0) ? msg : @"Đang tải...";
    lbl.textColor = kdy_gc(0x8E8E93, 1.0);
    lbl.font = [UIFont systemFontOfSize:15 weight:UIFontWeightMedium];
    lbl.textAlignment = NSTextAlignmentCenter;
    lbl.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;
    [root addSubview:lbl];

    /* dòng trạng thái (màu xám — dùng cho "đang thử lại...") */
    UILabel *status = [[UILabel alloc] initWithFrame:CGRectMake(24, b.size.height * 0.48 + 96, b.size.width - 48, 42)];
    status.textColor = kdy_gc(0x8E8E93, 1.0);
    status.font = [UIFont systemFontOfSize:13];
    status.textAlignment = NSTextAlignmentCenter;
    status.numberOfLines = 2;
    status.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;
    [root addSubview:status];
    g_kdy_status = status;
}

/* Màn LỖI KẾT NỐI — hiện khi hello thất bại ≥4 lần liên tiếp hoặc lỗi
 * cấu hình. Dừng tự retry (tránh "spinner xoay mãi mãi không lý do"),
 * hiện ĐÚNG nguyên nhân + nút THỬ LẠI để user chủ động thử lại. */
- (void)gate_state_error:(NSString *)reason {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self gate_state_error:reason]; });
        return;
    }
    [self gate_attach];
    if (!g_kdy_vc) return;

    UIView *root = g_kdy_vc.view;
    for (UIView *v in [root subviews]) [v removeFromSuperview];
    for (UIGestureRecognizer *gr in [root.gestureRecognizers copy]) {
        [root removeGestureRecognizer:gr];
    }
    g_kdy_input = nil;
    g_kdy_group = nil;
    g_kdy_status = nil;
    g_kdy_error_reason = [reason copy];

    CGRect b = root.bounds;
    if (CGRectIsEmpty(b)) b = [UIScreen mainScreen].bounds;

    [root addSubview:kdy_gate_background(b)];

    UIColor *accent = kdy_gc(0xD96B33, 1.0);

    CGFloat cw = MIN(b.size.width - 48.0, 360.0);
    CGFloat cx = (b.size.width - cw) / 2.0;
    CGFloat top = b.size.height * 0.26;

    UIView *badge = kdy_gate_badge(@"wifi.exclamationmark", @"⚠", accent, 88.0);
    badge.center = CGPointMake(b.size.width / 2.0, top + 44.0);
    badge.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin |
                             UIViewAutoresizingFlexibleBottomMargin;
    [root addSubview:badge];

    UILabel *t = [[UILabel alloc] initWithFrame:CGRectMake(0, top + 108, b.size.width, 26)];
    t.text = @"Không kết nối được server";
    t.textColor = kdy_gc(0x1C1C1E, 1.0);
    t.font = [UIFont systemFontOfSize:21 weight:UIFontWeightBold];
    t.textAlignment = NSTextAlignmentCenter;
    t.adjustsFontSizeToFitWidth = YES;
    t.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleBottomMargin;
    [root addSubview:t];

    /* thẻ trắng chứa lý do */
    UIView *card = [[UIView alloc] initWithFrame:CGRectMake(cx, top + 150, cw, 148)];
    kdy_gate_card(card);
    card.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin |
                            UIViewAutoresizingFlexibleBottomMargin;
    [root addSubview:card];

    UILabel *m = [[UILabel alloc] initWithFrame:CGRectMake(20, 16, cw - 40, 116)];
    m.text = (reason.length > 0) ? reason : @"Lý do không xác định.";
    m.textColor = kdy_gc(0x8E8E93, 1.0);
    m.font = [UIFont systemFontOfSize:13];
    m.textAlignment = NSTextAlignmentLeft;
    m.numberOfLines = 7;
    m.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    [card addSubview:m];

    UIButton *retryBtn = kdy_gate_button(@"Thử lại", CGRectMake(cx, top + 320, cw, 52), YES);
    retryBtn.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin |
                                UIViewAutoresizingFlexibleBottomMargin;
    [retryBtn addTarget:self action:@selector(kdy_retry_from_error) forControlEvents:UIControlEventTouchUpInside];
    [root addSubview:retryBtn];

    if (self.contactLink.length > 0) {
        UIButton *contact = [UIButton buttonWithType:UIButtonTypeSystem];
        contact.frame = CGRectMake(cx, top + 386, cw, 36);
        [contact setTitle:@"Liên hệ hỗ trợ" forState:UIControlStateNormal];
        [contact setTitleColor:kdy_gc(0x8E8E93, 1.0) forState:UIControlStateNormal];
        contact.titleLabel.font = [UIFont systemFontOfSize:13];
        contact.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin |
                                   UIViewAutoresizingFlexibleBottomMargin;
        [contact addTarget:self action:@selector(gate_contact_tapped) forControlEvents:UIControlEventTouchUpInside];
        [root addSubview:contact];
    }
}

- (void)gate_state_input {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self gate_state_input]; });
        return;
    }
    [self gate_attach];
    if (!g_kdy_vc) return;

    UIView *root = g_kdy_vc.view;
    for (UIView *v in [root subviews]) [v removeFromSuperview];
    for (UIGestureRecognizer *gr in [root.gestureRecognizers copy]) {
        [root removeGestureRecognizer:gr];
    }

    CGRect b = root.bounds;
    if (CGRectIsEmpty(b)) b = [UIScreen mainScreen].bounds;

    [root addSubview:kdy_gate_background(b)];

    UIViewAutoresizing centerMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin |
                                    UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;

    CGFloat cw = MIN(b.size.width - 48.0, 360.0);
    CGFloat cx = (b.size.width - cw) / 2.0;
    CGFloat top = MAX(24.0, b.size.height * 0.22);

    /* logo monogram */
    CGFloat logoSize = 64.0;
    UIView *logo = kdy_gate_logo(logoSize);
    logo.center = CGPointMake(b.size.width / 2.0, top + logoSize / 2.0);
    logo.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin |
                            UIViewAutoresizingFlexibleBottomMargin;
    [root addSubview:logo];

    /* nhãn KÍCH HOẠT — chữ giãn cách, cam đậm đọc rõ trên nền trắng */
    UILabel *kick = [[UILabel alloc] initWithFrame:CGRectMake(0, top + logoSize + 20, b.size.width, 16)];
    kick.attributedText = [[NSAttributedString alloc] initWithString:@"K Í C H   H O Ạ T"
                                                               attributes:@{
        NSFontAttributeName: [UIFont systemFontOfSize:12 weight:UIFontWeightBold],
        NSForegroundColorAttributeName: kdy_gc(0xC05A26, 1.0),
        NSKernAttributeName: @3.5,
    }];
    kick.textAlignment = NSTextAlignmentCenter;
    kick.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleBottomMargin;
    [root addSubview:kick];

    /* tên app — FreeFire Ds */
    UILabel *brand = [[UILabel alloc] initWithFrame:CGRectMake(0, top + logoSize + 42, b.size.width, 44)];
    brand.text = @"FreeFire Ds";
    brand.textColor = kdy_gc(0x1C1C1E, 1.0);
    brand.font = [UIFont systemFontOfSize:30 weight:UIFontWeightBold];
    brand.textAlignment = NSTextAlignmentCenter;
    brand.adjustsFontSizeToFitWidth = YES;
    brand.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleBottomMargin;
    [root addSubview:brand];

    /* thẻ trắng chứa ô key + nút LOGIN (cả thẻ rung khi sai) */
    UIView *group = [[UIView alloc] initWithFrame:CGRectMake(cx, top + logoSize + 104, cw, 168)];
    kdy_gate_card(group);
    group.autoresizingMask = centerMask;
    [root addSubview:group];
    g_kdy_group = group;

    UILabel *fieldLabel = [[UILabel alloc] initWithFrame:CGRectMake(16, 14, cw - 32, 18)];
    fieldLabel.text = @"Mã kích hoạt";
    fieldLabel.textColor = kdy_gc(0x8E8E93, 1.0);
    fieldLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightMedium];
    [group addSubview:fieldLabel];

    UITextField *tf = [[UITextField alloc] initWithFrame:CGRectMake(16, 40, cw - 32, 48)];
    tf.backgroundColor = kdy_gc(0xEFEFF4, 1.0);
    tf.layer.cornerRadius = 12.0;
    tf.textColor = kdy_gc(0x1C1C1E, 1.0);
    tf.font = [UIFont fontWithName:@"Menlo-Regular" size:15];
    tf.textAlignment = NSTextAlignmentNatural;
    tf.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"XXXX-XXXX-XXXX-XXXX"
                                                                attributes:@{NSForegroundColorAttributeName: kdy_gc(0x8E8E93, 1.0)}];
    tf.keyboardAppearance = UIKeyboardAppearanceDefault;
    tf.autocorrectionType = UITextAutocorrectionTypeNo;
    tf.autocapitalizationType = UITextAutocapitalizationTypeNone;
    tf.spellCheckingType = UITextSpellCheckingTypeNo;
    tf.keyboardType = UIKeyboardTypeASCIICapable;
    tf.returnKeyType = UIReturnKeyDone;
    tf.clearButtonMode = UITextFieldViewModeWhileEditing;
    if (@available(iOS 13.0, *)) {
        UIView *leftPad = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 40, 48)];
        UIImageView *keyIcon = [[UIImageView alloc] initWithImage:
            [UIImage systemImageNamed:@"key.fill"]];
        keyIcon.tintColor = kdy_gc(0x8E8E93, 1.0);
        keyIcon.frame = CGRectMake(14, 14, 20, 20);
        keyIcon.contentMode = UIViewContentModeScaleAspectFit;
        [leftPad addSubview:keyIcon];
        tf.leftView = leftPad;
        tf.leftViewMode = UITextFieldViewModeAlways;
    }
    [tf addTarget:self action:@selector(gate_login_tapped) forControlEvents:UIControlEventEditingDidEndOnExit];
    [group addSubview:tf];
    g_kdy_input = tf;

    UIButton *btn = kdy_gate_button(@"Đăng nhập", CGRectMake(16, 104, cw - 32, 52), YES);
    [btn addTarget:self action:@selector(gate_login_tapped) forControlEvents:UIControlEventTouchUpInside];
    [group addSubview:btn];

    /* dòng trạng thái */
    UILabel *status = [[UILabel alloc] initWithFrame:CGRectMake(cx, top + logoSize + 292, cw, 60)];
    status.textColor = kdy_gc(0xD5313B, 1.0);
    status.font = [UIFont systemFontOfSize:13];
    status.textAlignment = NSTextAlignmentCenter;
    status.numberOfLines = 3;
    status.autoresizingMask = centerMask;
    [root addSubview:status];
    g_kdy_status = status;

    /* liên hệ mờ sát đáy màn */
    if (self.contactLink.length > 0) {
        UIButton *contact = [UIButton buttonWithType:UIButtonTypeSystem];
        contact.frame = CGRectMake(cx, b.size.height - 84.0, cw, 32);
        [contact setTitle:@"Liên hệ hỗ trợ" forState:UIControlStateNormal];
        [contact setTitleColor:kdy_gc(0x8E8E93, 1.0) forState:UIControlStateNormal];
        contact.titleLabel.font = [UIFont systemFontOfSize:13];
        contact.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin |
                                   UIViewAutoresizingFlexibleTopMargin;
        [contact addTarget:self action:@selector(gate_contact_tapped) forControlEvents:UIControlEventTouchUpInside];
        [root addSubview:contact];
    }

    /* chạm nền → ẩn bàn phím */
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self
                                                                            action:@selector(gate_bg_tapped)];
    tap.cancelsTouchesInView = NO;
    [root addGestureRecognizer:tap];

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        [g_kdy_input becomeFirstResponder];
    });
}

- (void)gate_bg_tapped {
    [g_kdy_input resignFirstResponder];
}

- (void)gate_state_success:(NSString *)info {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self gate_state_success:info]; });
        return;
    }
    if (!g_kdy_vc) return;

    UIView *root = g_kdy_vc.view;
    for (UIView *v in [root subviews]) [v removeFromSuperview];
    for (UIGestureRecognizer *gr in [root.gestureRecognizers copy]) {
        [root removeGestureRecognizer:gr];
    }
    g_kdy_input = nil;
    g_kdy_group = nil;
    g_kdy_status = nil;

    CGRect b = root.bounds;
    if (CGRectIsEmpty(b)) b = [UIScreen mainScreen].bounds;

    [root addSubview:kdy_gate_background(b)];

    UIColor *okGreen = kdy_gc(0x1F9D57, 1.0);

    UIView *badge = kdy_gate_badge(@"checkmark", @"✓", okGreen, 88.0);
    badge.center = CGPointMake(b.size.width / 2.0, b.size.height * 0.36 + 44.0);
    badge.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin |
                            UIViewAutoresizingFlexibleBottomMargin;
    [root addSubview:badge];

    /* hiệu ứng nảy nhẹ khi hiện ✓ */
    badge.transform = CGAffineTransformMakeScale(0.3, 0.3);
    [UIView animateWithDuration:0.45
                          delay:0.05
         usingSpringWithDamping:0.55
          initialSpringVelocity:0.6
                        options:UIViewAnimationOptionCurveEaseOut
                     animations:^{
        badge.transform = CGAffineTransformIdentity;
    }
                     completion:nil];

    UILabel *t = [[UILabel alloc] initWithFrame:CGRectMake(0, b.size.height * 0.36 + 106, b.size.width, 26)];
    t.text = @"Kích hoạt thành công";
    t.textColor = kdy_gc(0x1C1C1E, 1.0);
    t.font = [UIFont systemFontOfSize:20 weight:UIFontWeightSemibold];
    t.textAlignment = NSTextAlignmentCenter;
    t.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleBottomMargin;
    [root addSubview:t];

    if (info.length > 0) {
        UILabel *d = [[UILabel alloc] initWithFrame:CGRectMake(24, b.size.height * 0.36 + 140, b.size.width - 48.0, 20)];
        d.text = info;
        d.textColor = kdy_gc(0x8E8E93, 1.0);
        d.font = [UIFont systemFontOfSize:14];
        d.textAlignment = NSTextAlignmentCenter;
        d.adjustsFontSizeToFitWidth = YES;
        d.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleBottomMargin;
        [root addSubview:d];
    }

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.3 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        /* Chỉ gỡ màn chắn khi state == AUTHORIZED và lease còn hạn —
         * gate_dismiss tự kiểm tra (điểm chốt cuối). */
        [self gate_dismiss];
    });
}

- (void)gate_state_maintenance {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self gate_state_maintenance]; });
        return;
    }
    [self gate_attach];
    if (!g_kdy_vc) return;

    UIView *root = g_kdy_vc.view;
    for (UIView *v in [root subviews]) [v removeFromSuperview];
    for (UIGestureRecognizer *gr in [root.gestureRecognizers copy]) {
        [root removeGestureRecognizer:gr];
    }
    g_kdy_input = nil;
    g_kdy_group = nil;
    g_kdy_status = nil;

    CGRect b = root.bounds;
    if (CGRectIsEmpty(b)) b = [UIScreen mainScreen].bounds;

    [root addSubview:kdy_gate_background(b)];

    UIColor *accent = kdy_gc(0xD96B33, 1.0);

    CGFloat cw = MIN(b.size.width - 48.0, 360.0);
    CGFloat cx = (b.size.width - cw) / 2.0;
    CGFloat top = b.size.height * 0.26;

    UIView *badge = kdy_gate_badge(@"wrench.and.screwdriver", @"🛠", accent, 88.0);
    badge.center = CGPointMake(b.size.width / 2.0, top + 44.0);
    badge.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin |
                             UIViewAutoresizingFlexibleBottomMargin;
    [root addSubview:badge];

    UILabel *t = [[UILabel alloc] initWithFrame:CGRectMake(0, top + 108, b.size.width, 26)];
    t.text = @"Bảo trì hệ thống";
    t.textColor = kdy_gc(0x1C1C1E, 1.0);
    t.font = [UIFont systemFontOfSize:21 weight:UIFontWeightBold];
    t.textAlignment = NSTextAlignmentCenter;
    t.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleBottomMargin;
    [root addSubview:t];

    UILabel *m = [[UILabel alloc] initWithFrame:CGRectMake(cx, top + 146, cw, 44)];
    m.text = @"Hệ thống đang bảo trì. Vui lòng quay lại sau.";
    m.textColor = kdy_gc(0x8E8E93, 1.0);
    m.font = [UIFont systemFontOfSize:14];
    m.textAlignment = NSTextAlignmentCenter;
    m.numberOfLines = 2;
    m.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleBottomMargin;
    [root addSubview:m];

    if (self.contactLink.length > 0) {
        UIButton *contact = kdy_gate_button(@"Liên hệ hỗ trợ", CGRectMake(cx, top + 212, cw, 52), YES);
        contact.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleBottomMargin;
        [contact addTarget:self action:@selector(gate_contact_tapped) forControlEvents:UIControlEventTouchUpInside];
        [root addSubview:contact];
    }

    UIButton *exitBtn = kdy_gate_button(@"Thoát", CGRectMake(cx, top + 278, cw, 48), NO);
    exitBtn.titleLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightSemibold];
    exitBtn.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleBottomMargin;
    [exitBtn addTarget:self action:@selector(gate_exit_tapped) forControlEvents:UIControlEventTouchUpInside];
    [root addSubview:exitBtn];
}

- (void)gate_dismiss {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self gate_dismiss]; });
        return;
    }

    /* ĐIỂM CHỐT CUỐI: chỉ mở khóa khi state machine đang AUTHORIZED
     * và lease (đã verify chữ ký) còn hạn. Gọi gate_dismiss bằng hook
     * mà không có authorization → tự quay lại màn nhập key. */
    LicenseCore *core = [LicenseCore sharedCore];
    if (core.state != LicenseStateAuthorized || ![core sessionUsable]) {
        /* FIX BUG đá về màn nhập key (lớp 3): state kẹt ở dạng lành tính
         * (NET_INIT/KEY_PENDING/CHALLENGE/AUTHENTICATING — do transition bị
         * reject âm thầm) nhưng lease ĐÃ VERIFY chữ ký + còn hạn → hồi phục
         * AUTHORIZED thay vì đá user ra. KHÔNG hồi phục khi LOCKED/REVOKED/
         * EXPIRED — server đã từ chối có chủ đích (lease bị clear rồi). */
        LicenseState st = core.state;
        BOOL benignStuck = (st == LicenseStateNetInit || st == LicenseStateKeyPending
                            || st == LicenseStateChallenge || st == LicenseStateAuthenticating);
        if (benignStuck && [core leaseAliveIgnoringState]) {
            [LicenseCore diag:@"[LICENSE] gate_dismiss: state kẹt %@ + lease còn hạn — hồi phục AUTHORIZED",
                LicenseStateName(st)];
            [core ensureAuthorized];
        }
    }
    if (core.state != LicenseStateAuthorized || ![core sessionUsable]) {
        [LicenseCore diag:@"[LICENSE] gate_dismiss bị chặn (state=%@ usable=%d)",
            LicenseStateName(core.state), (int)[core sessionUsable]];
        [self gate_state_input];
        return;
    }

    if (g_kdy_app_window) {
        /* MỞ KHÓA: trả root gốc về cho CHÍNH cửa sổ của app */
        UIWindow *win = g_kdy_app_window;
        UIViewController *restore = g_kdy_orig_root;
        if (!restore) {
            restore = [[UIViewController alloc] init];
            restore.view.backgroundColor = kdy_gc(0xF2F2F7, 1.0);
        }
        g_kdy_app_window = nil;
        g_kdy_vc = nil;
        g_kdy_input = nil;
        g_kdy_group = nil;
        g_kdy_status = nil;
        g_kdy_orig_root = nil;
        [UIView transitionWithView:win
                            duration:0.35
                             options:(UIViewAnimationOptionTransitionCrossDissolve | UIViewAnimationOptionLayoutSubviews)
                          animations:^{
            win.rootViewController = restore;
        }
                          completion:^(BOOL finished) {
            [win makeKeyAndVisible];
        }];
        [self kdy_drop_tmp_window];
        [self kdy_resume_observe];
        return;
    }

    /* chế độ cửa sổ tạm (dự phòng khi app không có cửa sổ chính) */
    if (!g_kdy_tmp_window) return;

    UIWindow *w = g_kdy_tmp_window;
    UIWindowScene *scene = (UIWindowScene *)w.windowScene;
    UIWindow *restoreWin = nil;
    if (scene) {
        for (UIWindow *win in scene.windows) {
            if (win != w) { restoreWin = win; break; }
        }
    }

    g_kdy_tmp_window = nil;
    g_kdy_vc = nil;
    g_kdy_input = nil;
    g_kdy_group = nil;
    g_kdy_status = nil;

    [UIView animateWithDuration:0.35
                          delay:0.0
                        options:UIViewAnimationOptionCurveEaseOut
                     animations:^{
        w.alpha = 0.0;
    }
                     completion:^(BOOL finished) {
        w.hidden = YES;
        [w removeFromSuperview];
        if (restoreWin) [restoreWin makeKeyWindow];
    }];
    [self kdy_resume_observe];
}

- (void)gate_set_status:(NSString *)msg color:(UIColor *)color shake:(BOOL)shake {
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self gate_set_status:msg color:color shake:shake]; });
        return;
    }
    if (g_kdy_status) {
        g_kdy_status.text = msg;
        g_kdy_status.textColor = color ?: kdy_gc(0xD5313B, 1.0);
    }
    if (shake && g_kdy_group) {
        [UIView animateKeyframesWithDuration:0.45
                                         delay:0.0
                                       options:UIViewKeyframeAnimationOptionCalculationModeLinear
                                    animations:^{
            [UIView addKeyframeWithRelativeStartTime:0.0 relativeDuration:0.2 animations:^{
                g_kdy_group.transform = CGAffineTransformMakeTranslation(-12, 0);
            }];
            [UIView addKeyframeWithRelativeStartTime:0.2 relativeDuration:0.2 animations:^{
                g_kdy_group.transform = CGAffineTransformMakeTranslation(12, 0);
            }];
            [UIView addKeyframeWithRelativeStartTime:0.4 relativeDuration:0.2 animations:^{
                g_kdy_group.transform = CGAffineTransformMakeTranslation(-7, 0);
            }];
            [UIView addKeyframeWithRelativeStartTime:0.6 relativeDuration:0.2 animations:^{
                g_kdy_group.transform = CGAffineTransformMakeTranslation(7, 0);
            }];
            [UIView addKeyframeWithRelativeStartTime:0.8 relativeDuration:0.2 animations:^{
                g_kdy_group.transform = CGAffineTransformIdentity;
            }];
        }
                                    completion:nil];
    }
}

- (void)gate_login_tapped {
    if (g_kdy_in_auth) return;   /* đang auth — bỏ double-tap */
    NSString *k = g_kdy_input.text ?: @"";
    if (k.length > 0) {
        [g_kdy_input resignFirstResponder];
        [self checkKey:k isAuto:NO];
    } else {
        [self gate_set_status:@"Vui lòng nhập key"
                        color:kdy_gc(0xD5313B, 1.0)
                        shake:YES];
    }
}

- (void)gate_contact_tapped {
    NSString *link = self.contactLink;
    if (link.length > 0) {
        NSURL *u = [NSURL URLWithString:link];
        if (u) {
            [[UIApplication sharedApplication] openURL:u options:@{} completionHandler:nil];
        }
    }
}

- (void)gate_exit_tapped {
    exit(0);
}

#pragma mark - Alerts / exit (chỉ theo lệnh CÓ CHỮ KÝ của server)

/* force_exit: server ký yêu cầu thoát (vd Package Token không tồn tại).
 * Hiện alert + nút Thoát + exit dự phòng 8s. KHÔNG còn exit đa đường. */
- (void)forceExitApp:(NSString *)reason {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIViewController *rootVC = [self gate_presenter];

        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(8.0 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            exit(0);
        });

        if (rootVC) {
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Lỗi Hệ Thống"
                                                                             message:reason
                                                                      preferredStyle:UIAlertControllerStyleAlert];
            [alert addAction:[UIAlertAction actionWithTitle:@"Thoát"
                                                       style:UIAlertActionStyleDestructive
                                                     handler:^(UIAlertAction *action) {
                exit(0);
            }]];
            [rootVC presentViewController:alert animated:YES completion:nil];
        } else {
            exit(0);
        }
    });
}

- (void)showAlert:(NSString *)title message:(NSString *)message retry:(BOOL)retry {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIViewController *rootVC = [self gate_presenter];
        if (!rootVC || !title) return;

        UIAlertController *alert = [UIAlertController alertControllerWithTitle:title
                                                                        message:message
                                                                 preferredStyle:UIAlertControllerStyleAlert];

        if (self.contactLink.length > 0) {
            [alert addAction:[UIAlertAction actionWithTitle:@"Liên hệ"
                                                       style:UIAlertActionStyleDefault
                                                     handler:^(UIAlertAction *action) {
                NSURL *u = [NSURL URLWithString:self.contactLink];
                if (u) {
                    [[UIApplication sharedApplication] openURL:u options:@{} completionHandler:nil];
                }
                if (retry) {
                    [self gate_state_input];
                }
            }]];
        }
        [alert addAction:[UIAlertAction actionWithTitle:@"OK"
                                                   style:UIAlertActionStyleDefault
                                                 handler:^(UIAlertAction *action) {
            if (retry) {
                [self gate_state_input];
            }
        }]];
        [rootVC presentViewController:alert animated:YES completion:nil];
    });
}

@end
