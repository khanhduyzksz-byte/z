// Core/OffsetRegistry.mm — sinh bởi scripts/gen_offset_registry.py
// (đừng sửa tay bảng slot — chạy lại generator + verify_offsets_gate.py).

#import "OffsetRegistry.h"
#import "GameOffsets.h"

#include <atomic>
#include <cstdlib>
#include <cstring>
#include <errno.h>

#import <Foundation/Foundation.h>

namespace {

enum SlotKind : uint8_t {
    SlotU64 = 0,
    SlotI32 = 1,
    SlotU32 = 2,
};

struct OffsetSlot {
    const char *name;
    uint8_t kind;
    void *slot;
};

/* BẢNG SLOT — sinh tự động, 1:1 với namespace GameOffsets. */
OffsetSlot kSlots[] = {
    {"GameFacadeTypeInfo", SlotU64, &GameOffsets::GameFacadeTypeInfo},
    {"GameVarDefTypeInfo", SlotU64, &GameOffsets::GameVarDefTypeInfo},
    {"Il2CppClassStaticFields", SlotU64, &GameOffsets::Il2CppClassStaticFields},
    {"GameFacadeCurrentGame", SlotU64, &GameOffsets::GameFacadeCurrentGame},
    {"GameFacadeCurrentMatchGame", SlotU64, &GameOffsets::GameFacadeCurrentMatchGame},
    {"GameFacadeIsObserver", SlotU64, &GameOffsets::GameFacadeIsObserver},
    {"GameFacadeIsMatchStarted", SlotU64, &GameOffsets::GameFacadeIsMatchStarted},
    {"BaseGameHasInited", SlotU64, &GameOffsets::BaseGameHasInited},
    {"BaseGameHasLoadingFailed", SlotU64, &GameOffsets::BaseGameHasLoadingFailed},
    {"BaseGameHasFixedUpdated", SlotU64, &GameOffsets::BaseGameHasFixedUpdated},
    {"BaseGameSceneLoaded", SlotU64, &GameOffsets::BaseGameSceneLoaded},
    {"BaseGameIsPaused", SlotU64, &GameOffsets::BaseGameIsPaused},
    {"BaseGameIsMatchEnd", SlotU64, &GameOffsets::BaseGameIsMatchEnd},
    {"MatchGameMatch", SlotU64, &GameOffsets::MatchGameMatch},
    {"MatchGameGRIDataPool", SlotU64, &GameOffsets::MatchGameGRIDataPool},
    {"MatchGameCameraControllerManager", SlotU64, &GameOffsets::MatchGameCameraControllerManager},
    {"CameraControllerManagerGameCamera", SlotU64, &GameOffsets::CameraControllerManagerGameCamera},
    {"CameraControllerManagerAltCamera", SlotU64, &GameOffsets::CameraControllerManagerAltCamera},
    {"MatchLocalPlayer", SlotU64, &GameOffsets::MatchLocalPlayer},
    {"MatchShortIdToPlayers", SlotU64, &GameOffsets::MatchShortIdToPlayers},
    {"EntityIsRecycle", SlotU64, &GameOffsets::EntityIsRecycle},
    {"EntityCachedTransform", SlotU64, &GameOffsets::EntityCachedTransform},
    {"EntityPRIReceivedFirstTime", SlotU64, &GameOffsets::EntityPRIReceivedFirstTime},
    {"PlayerPRIDataPool", SlotU64, &GameOffsets::PlayerPRIDataPool},
    {"PlayerIsDead", SlotU64, &GameOffsets::PlayerIsDead},
    {"PlayerUGCStartFiring", SlotU64, &GameOffsets::PlayerUGCStartFiring},
    {"PlayerIsInZeppelin", SlotU64, &GameOffsets::PlayerIsInZeppelin},
    {"PlayerLastStartFireTime", SlotU64, &GameOffsets::PlayerLastStartFireTime},
    {"PlayerMainCameraTransform", SlotU64, &GameOffsets::PlayerMainCameraTransform},
    {"PlayerId", SlotU64, &GameOffsets::PlayerId},
    {"PlayerNickName", SlotU64, &GameOffsets::PlayerNickName},
    {"PlayerOriginalNickName", SlotU64, &GameOffsets::PlayerOriginalNickName},
    {"PlayerIsClientBot", SlotU64, &GameOffsets::PlayerIsClientBot},
    {"PlayerAvatarInitialized", SlotU64, &GameOffsets::PlayerAvatarInitialized},
    {"PlayerIsInVehicle", SlotU64, &GameOffsets::PlayerIsInVehicle},
    {"PlayerAimRotation", SlotU64, &GameOffsets::PlayerAimRotation},
    {"PlayerAimRotationAux", SlotU64, &GameOffsets::PlayerAimRotationAux},
    {"PlayerModelVisibilityState", SlotU64, &GameOffsets::PlayerModelVisibilityState},
    {"PlayerIsKnockedDownBleed", SlotU64, &GameOffsets::PlayerIsKnockedDownBleed},
    {"PlayerIsKnockDownBleedingFromGS", SlotU64, &GameOffsets::PlayerIsKnockDownBleedingFromGS},
    {"PlayerCurrentAimRotation", SlotU64, &GameOffsets::PlayerCurrentAimRotation},
    {"PlayerBeingRescuredState", SlotU64, &GameOffsets::PlayerBeingRescuredState},
    {"PlayerPhysXData", SlotU64, &GameOffsets::PlayerPhysXData},
    {"PhysXStateClassRef", SlotU64, &GameOffsets::PhysXStateClassRef},
    {"PhysXGhgState", SlotU64, &GameOffsets::PhysXGhgState},
    {"PlayerHeadNode", SlotU64, &GameOffsets::PlayerHeadNode},
    {"PlayerHipNode", SlotU64, &GameOffsets::PlayerHipNode},
    {"PlayerLeftAnkleNode", SlotU64, &GameOffsets::PlayerLeftAnkleNode},
    {"PlayerRightAnkleNode", SlotU64, &GameOffsets::PlayerRightAnkleNode},
    {"PlayerLeftToeNode", SlotU64, &GameOffsets::PlayerLeftToeNode},
    {"PlayerRightToeNode", SlotU64, &GameOffsets::PlayerRightToeNode},
    {"PlayerLeftShoulderNode", SlotU64, &GameOffsets::PlayerLeftShoulderNode},
    {"PlayerRightShoulderNode", SlotU64, &GameOffsets::PlayerRightShoulderNode},
    {"PlayerRightHandNode", SlotU64, &GameOffsets::PlayerRightHandNode},
    {"PlayerLeftHandNode", SlotU64, &GameOffsets::PlayerLeftHandNode},
    {"PlayerRightForeArmNode", SlotU64, &GameOffsets::PlayerRightForeArmNode},
    {"PlayerLeftForeArmNode", SlotU64, &GameOffsets::PlayerLeftForeArmNode},
    {"PlayerSpineBone", SlotU64, &GameOffsets::PlayerSpineBone},
    {"PlayerHeadBone", SlotU64, &GameOffsets::PlayerHeadBone},
    {"PlayerHipsBone", SlotU64, &GameOffsets::PlayerHipsBone},
    {"GameVarDefSensitivityBlock", SlotU64, &GameOffsets::GameVarDefSensitivityBlock},
    {"GameVarDefRotationSensitivityMax", SlotU64, &GameOffsets::GameVarDefRotationSensitivityMax},
    {"GameVarDefAimRotationSensitivityMin", SlotU64, &GameOffsets::GameVarDefAimRotationSensitivityMin},
    {"GameVarDefAimRotationSensitivityMax", SlotU64, &GameOffsets::GameVarDefAimRotationSensitivityMax},
    {"PlayerAuxAimResetTime", SlotU64, &GameOffsets::PlayerAuxAimResetTime},
    {"PlayerMinAngleX", SlotU64, &GameOffsets::PlayerMinAngleX},
    {"PlayerMaxAngleX", SlotU64, &GameOffsets::PlayerMaxAngleX},
    {"PlayerPhysicalCCT", SlotU64, &GameOffsets::PlayerPhysicalCCT},
    {"PhysicalCCTVelocity", SlotU64, &GameOffsets::PhysicalCCTVelocity},
    {"PlayerInventoryManager", SlotU64, &GameOffsets::PlayerInventoryManager},
    {"InventoryItemOnHand", SlotU64, &GameOffsets::InventoryItemOnHand},
    {"WeaponRepItem", SlotU64, &GameOffsets::WeaponRepItem},
    {"WeaponRange", SlotU64, &GameOffsets::WeaponRange},
    {"WeaponFireInterval", SlotU64, &GameOffsets::WeaponFireInterval},
    {"WeaponFullDamageDistance", SlotU64, &GameOffsets::WeaponFullDamageDistance},
    {"WeaponIsSingleShot", SlotU64, &GameOffsets::WeaponIsSingleShot},
    {"DictionaryEntries", SlotU64, &GameOffsets::DictionaryEntries},
    {"DictionaryCount", SlotU64, &GameOffsets::DictionaryCount},
    {"ArrayLength", SlotU64, &GameOffsets::ArrayLength},
    {"ArrayItems", SlotU64, &GameOffsets::ArrayItems},
    {"BytePlayerEntryValue", SlotU64, &GameOffsets::BytePlayerEntryValue},
    {"BytePlayerEntrySize", SlotU64, &GameOffsets::BytePlayerEntrySize},
    {"StringLength", SlotU64, &GameOffsets::StringLength},
    {"StringFirstChar", SlotU64, &GameOffsets::StringFirstChar},
    {"ReplicationDataPoolData", SlotU64, &GameOffsets::ReplicationDataPoolData},
    {"ReplicationDataGroup", SlotU64, &GameOffsets::ReplicationDataGroup},
    {"ReplicationDataValue", SlotU64, &GameOffsets::ReplicationDataValue},
    {"TransformNodeTransform", SlotU64, &GameOffsets::TransformNodeTransform},
    {"PriVarScope", SlotI32, &GameOffsets::PriVarScope},
    {"PriVarFire", SlotI32, &GameOffsets::PriVarFire},
    {"ReplicationGroupUInt8", SlotU32, &GameOffsets::ReplicationGroupUInt8},
    {"ReplicationGroupUInt16", SlotU32, &GameOffsets::ReplicationGroupUInt16},
    {"ReplicationGroupUInt32", SlotU32, &GameOffsets::ReplicationGroupUInt32},
    {"PhysXPoseSkyDiving", SlotU32, &GameOffsets::PhysXPoseSkyDiving},
    {"PhysXPoseKnockDown", SlotU32, &GameOffsets::PhysXPoseKnockDown},
    {"PhysXPoseParachuteFalling", SlotU32, &GameOffsets::PhysXPoseParachuteFalling},
    {"UnityObjectCachedPtr", SlotU64, &GameOffsets::UnityObjectCachedPtr},
    {"TransformAccess", SlotU64, &GameOffsets::TransformAccess},
    {"TransformIndex", SlotU64, &GameOffsets::TransformIndex},
    {"TransformData", SlotU64, &GameOffsets::TransformData},
    {"TransformParents", SlotU64, &GameOffsets::TransformParents},
    {"BitArrayBooleanValue", SlotU64, &GameOffsets::BitArrayBooleanValue},
    {"BitArrayBooleanInitialValue", SlotU64, &GameOffsets::BitArrayBooleanInitialValue},
    {"BitArrayBooleanMode", SlotU64, &GameOffsets::BitArrayBooleanMode},
    {"BitArrayBooleanAndTrue", SlotI32, &GameOffsets::BitArrayBooleanAndTrue},
    {"BitArrayBooleanOrTrue", SlotI32, &GameOffsets::BitArrayBooleanOrTrue},
};

std::atomic<bool> g_ready{false};

void slotsZero() {
    for (size_t i = 0; i < sizeof(kSlots) / sizeof(kSlots[0]); i++) {
        switch (kSlots[i].kind) {
            case SlotU64: *static_cast<uint64_t *>(kSlots[i].slot) = 0; break;
            case SlotI32: *static_cast<int32_t *>(kSlots[i].slot) = 0; break;
            case SlotU32: *static_cast<uint32_t *>(kSlots[i].slot) = 0; break;
        }
    }
}

bool slotApply(const OffsetSlot &s, unsigned long long v) {
    switch (s.kind) {
        case SlotU64: *static_cast<uint64_t *>(s.slot) = (uint64_t)v; return true;
        case SlotI32: *static_cast<int32_t *>(s.slot) = (int32_t)v; return true;
        case SlotU32: *static_cast<uint32_t *>(s.slot) = (uint32_t)v; return true;
    }
    return false;
}

} // namespace

extern "C" bool kdy_offsets_ready(void) {
    return g_ready.load(std::memory_order_acquire);
}

extern "C" const char *kdy_offsets_version(void) {
    return GameOffsets::ExpectedGameVersion;
}

extern "C" bool kdy_offsets_apply_json(const char *utf8, size_t len,
                                       const char *version, size_t version_len) {
    /* Đang áp lại (offset mới từ server) → hạ ready trước khi ghi để
     * gate chặn các tick trong lúc đổ dữ liệu. */
    g_ready.store(false, std::memory_order_release);

    if (utf8 == NULL || len == 0 || len > 131072) return false;
    NSData *data = [[NSData alloc] initWithBytes:reinterpret_cast<const void *>(utf8)
                                          length:(NSUInteger)len];
    if (data == nil) return false;

    id parsed = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    if (![parsed isKindOfClass:[NSDictionary class]]) return false;
    NSDictionary *dict = (NSDictionary *)parsed;

    /* MỌI slot phải có trong payload — thiếu 1 tên là từ chối cả payload. */
    const size_t slotCount = sizeof(kSlots) / sizeof(kSlots[0]);
    for (size_t i = 0; i < slotCount; i++) {
        NSString *key = [NSString stringWithUTF8String:kSlots[i].name];
        if (key == nil) return false;
        id val = dict[key];
        if (![val isKindOfClass:[NSString class]]) return false;
        const char *c = [(NSString *)val UTF8String];
        if (c == NULL) return false;

        errno = 0;
        char *end = NULL;
        unsigned long long v = strtoull(c, &end, 0);
        if (end == c || *end != '\0' || errno == ERANGE) return false;
        if (!slotApply(kSlots[i], v)) return false;
    }

    /* Runtime layout check (thay 2 static_assert cũ): Dictionary<byte,
     * Player>.Entry do struct compile-time quyết định — nếu offset từ
     * server không khớp struct nghĩa là payload lệch bản → từ chối. */
    if (GameOffsets::BytePlayerEntrySize != sizeof(BytePlayerDictionaryEntry)
        || GameOffsets::BytePlayerEntryValue != offsetof(BytePlayerDictionaryEntry, value)) {
        slotsZero();
        return false;
    }

    memset(GameOffsets::ExpectedGameVersion, 0,
           sizeof(GameOffsets::ExpectedGameVersion));
    if (version != NULL && version_len > 0) {
        size_t cap = sizeof(GameOffsets::ExpectedGameVersion) - 1;
        size_t n = (version_len < cap) ? version_len : cap;
        memcpy(GameOffsets::ExpectedGameVersion, version, n);
    }

    g_ready.store(true, std::memory_order_release);
    return true;
}

extern "C" void kdy_offsets_reset(void) {
    g_ready.store(false, std::memory_order_release);
    memset(GameOffsets::ExpectedGameVersion, 0,
           sizeof(GameOffsets::ExpectedGameVersion));
    slotsZero();
}
