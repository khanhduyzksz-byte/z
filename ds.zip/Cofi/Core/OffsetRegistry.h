#ifndef OffsetRegistry_h
#define OffsetRegistry_h

// ======================================================================
//  OffsetRegistry — cổng offset duy nhất của client (Task 17).
//
//  Offset game KHÔNG nằm trong binary. Registry chỉ được đổ giá trị từ
//  payload action=offsets của server SAU khi DuyServer verify chữ ký
//  ECDSA + device_binding + lease. Gate: kdy_offsets_ready().
//
//  Pure C API (extern "C") để gọi được từ cả .m lẫn .mm.
// ======================================================================

#include <stdbool.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* TRUE chỉ khi một payload ĐÃ verify được áp thành công và chưa bị reset. */
bool kdy_offsets_ready(void);

/* Chuỗi phiên bản game của bộ offset đang chạy (rỗng nếu chưa ready). */
const char *kdy_offsets_version(void);

/*
 * Áp payload JSON {"Name":"0x...", ...} + phiên bản game.
 * FAIL-CLOSED: thiếu 1 slot / giá trị không parse được / layout struct
 * lệch → trả về false, KHÔNG áp gì cả (toàn bộ giữ nguyên trạng thái cũ
 * — thường là toàn 0 = ESP/Aim chết).
 */
bool kdy_offsets_apply_json(const char *utf8, size_t len,
                            const char *version, size_t version_len);

/* Zero toàn bộ slot + version + ready=false (lockdown / revoke / hết hạn). */
void kdy_offsets_reset(void);

#ifdef __cplusplus
}
#endif

#endif /* OffsetRegistry_h */
