#ifndef HeaderAPI_h
#define HeaderAPI_h

#import <Foundation/Foundation.h>

// ======================================================================
//  CẤU HÌNH API — KHỚP VỚI SERVER (TemplateAPIKEY / khanhduyz.fun)
//
//  • kBaseAPIURL: domain + đường dẫn tới file API trên server.
//    Server zip được deploy ở thư mục gốc của https://khanhduyz.fun/
//    → endpoint thật là: https://khanhduyz.fun/api/connect.php
//
//  • kPackageToken: Project Token (32 ký tự hex) từ admin → Packages
//
//  • kLicensePublicKeyPEM: PUBLIC KEY ký phản hồi V2 (ECDSA P-256).
//    Đây là PUBLIC key — an toàn để nhúng trong app.
//    PRIVATE key ký nằm trên server (includes/signing_key.php).
// ======================================================================

static NSString *const kBaseAPIURL = @"https://khanhduyz.fun/api/connect.php";

// ⬇️⬇️ Project Token của bạn ⬇️⬇️
static NSString *const kPackageToken = @"d20f4cfede4042aa85f90c42b0ddaa10";

// ⬇️ PUBLIC KEY server (PEM SPKI P-256) — đã fix lỗi xuống dòng ⬇️
static NSString *const kLicensePublicKeyPEM =
    @"-----BEGIN PUBLIC KEY-----\n"
    @"MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEPgZcRYvldG9cQOraj/dDW5MGggKj\n"
    @"ypJWq7ESpan1fzbCDKnHDEaf5P4A7rUKEeUXpVxnymjNo2ZbHnO6zbMFAg==\n"
    @"-----END PUBLIC KEY-----";

// ======================================================================
//  Giao thức V2 (server-authoritative signed lease) — xem DuyServer.mm
// ======================================================================
static const NSInteger kLicenseProtocolVersion = 2;

#endif /* HeaderAPI_h */
